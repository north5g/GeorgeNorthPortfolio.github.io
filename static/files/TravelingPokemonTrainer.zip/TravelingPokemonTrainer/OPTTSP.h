// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#ifndef OPTTSP_H
#define OPTTSP_H

#include <getopt.h>
#include <cstdint>
#include <iostream>
#include <vector>
#include <cmath>
#include "map.h"

using namespace std;
/**/
class OPTfunction {
    public:
        double upperBound;
        vector<int> bestList;
        vector<int> currentList;
        vector<node> pokedex;
        double currentWeight = 0;

    double generateMST(vector<int> &list) {
        //list is the number of all nodes NOT set

            for (size_t i = 0; i < list.size(); i++) {
                pokedex[list[i]].found = false;
                pokedex[list[i]].weight = numeric_limits<double>::infinity();
            }
                
            pokedex[list[0]].weight = 0;
            int vectorTracker = 0;
            double vectorTrackerWeight = numeric_limits<double>::infinity();

            //step 0: other steps, but with more predictability to skip a loop
            //know that region[0] is shortest distance
            pokedex[list[0]].found = true;
            for (size_t i = 1; i < list.size(); i++) {
                vectorTrackerWeight = TSPdistance(pokedex[list[0]], pokedex[list[i]]);
                //if new weight less, connect this to prev 
                if (vectorTrackerWeight < pokedex[list[i]].weight) {
                    pokedex[list[i]].weight = vectorTrackerWeight;
                    pokedex[list[i]].prevNode = 0;
                    }
            }

            //go through and find shortest limit for every node, loop
            //happens nodeCount - 1 times
            for (size_t i = 1; i < list.size(); i++) { //find MST

            vectorTrackerWeight = numeric_limits<double>::infinity();

            //step 1: find smallest distance not found yet
            for (size_t i = 1; i < list.size(); i++) {
                if (!pokedex[list[i]].found) {
                    if (pokedex[list[i]].weight < vectorTrackerWeight) {
                        vectorTrackerWeight = pokedex[list[i]].weight;
                        vectorTracker = int(i);
                    }
                }
            }

            //step 2: change node to found
            pokedex[list[vectorTracker]].found = true;

            //step 3: find new shortest distance connecting that to other nodes
            //vectorTrackerWeight is not needed now, use as flex value
            for (size_t i = 1; i < list.size(); i++) {
                if (!pokedex[list[i]].found) {
                    vectorTrackerWeight = TSPdistance(pokedex[list[vectorTracker]], pokedex[list[i]]);
                    //if new weight less, connect this to prev 
                    if (vectorTrackerWeight < pokedex[list[i]].weight) {
                        pokedex[list[i]].weight = vectorTrackerWeight;
                        pokedex[list[i]].prevNode = vectorTracker;
                    }
                }
            }

            }//end of finding MST

            //final calculation
            double totalWeight = 0;
            double temp;
            for (size_t i = 0; i < list.size(); i++) {
                temp = pokedex[list[i]].weight;
                totalWeight += sqrt(temp);
            }


            return totalWeight;
    }

    void generateTSP() {
        
            vector<int> tracker;
            tracker.resize(pokedex.size());
            int vectorTracker = 0;
            double vectorTrackerWeight = numeric_limits<double>::infinity();
            tracker[0] = 1; //beginning
            tracker[1] = 0; //middle
            double currentWeight = 0;
            double totalWeight = sqrt(TSPdistance(pokedex[0], pokedex[1])) +
                        sqrt(TSPdistance(pokedex[1], pokedex[0]));

            for (int i = 2; i < int(pokedex.size()); i++) {
                //used to add every node into the vector
                for (size_t j = 0; int(j) < i; j++) {
                    currentWeight = sqrt(TSPdistance(pokedex[j], pokedex[i])) +
                        sqrt(TSPdistance(pokedex[i], pokedex[tracker[j]]));
                    currentWeight -= sqrt(TSPdistance(pokedex[j], pokedex[tracker[j]]));
                    if (currentWeight < vectorTrackerWeight) {
                        vectorTrackerWeight = currentWeight;
                        vectorTracker = int(j);
                    }
                }

                //update with smallest
                totalWeight += vectorTrackerWeight;
                vectorTrackerWeight = numeric_limits<double>::infinity();
                //need vectorTracker = i without disturing order
                tracker[i] = tracker[vectorTracker];
                tracker[vectorTracker] = i;
            }

            upperBound = totalWeight;
            currentList.clear();
            currentList.reserve(pokedex.size());
            bestList.reserve(pokedex.size());
            int path = 0;
            for (size_t i = 0; i < pokedex.size(); i++) {
                bestList.push_back(path);
                path = tracker[path];
            }
            currentList = bestList;

    }

    //creates tsp and mst

    void print() {
        cout << upperBound << '\n';

        for (size_t i = 0 ; i < bestList.size(); i++) {
            cout << bestList[i] << ' ';
        }
    }

    bool promising(size_t permLength) {

        if ((currentList.size() - permLength) <= 5) { return true; }

        //get length of path of permLength
        double measuredWeight = 0;
        for (int i = 0; i < int(permLength) - 1; i++) {
            measuredWeight += sqrt(TSPdistance(pokedex[currentList[i]], pokedex[currentList[i+1]]));
        }

        //get length of mst of rest of list
        vector<int> tempList;
        while(permLength < currentList.size()) {
            tempList.push_back(currentList[permLength]);
            permLength++;
        }
        measuredWeight += generateMST(tempList);

        //connect path to MST
        double temp;
        double bestPart1 = numeric_limits<double>::infinity();
        double bestPart2 = numeric_limits<double>::infinity();
        for (size_t i = 0; i < tempList.size(); i++) {
            temp = sqrt(TSPdistance(pokedex[currentList[0]], pokedex[tempList[i]]));
            if (temp < bestPart2) {
                bestPart2 = temp; //don't need to track i node, right?
            }

            temp = sqrt(TSPdistance(pokedex[currentList[permLength - 1]], pokedex[tempList[i]]));
            if (temp < bestPart1) {
                bestPart1 = temp; //don't need to track i node, right?
            }
        }

        measuredWeight += bestPart1;
        measuredWeight += bestPart2;


        if (upperBound < measuredWeight) {
            return false;
        }
        return true;

    }

    void genPerms(size_t permLength) {
        if (permLength == currentList.size()) {
        // Do something with the path

            double temp = sqrt(TSPdistance(pokedex[currentList[0]],pokedex[currentList[permLength - 1]]));

            currentWeight += temp;

            if (currentWeight < upperBound) {
                bestList = currentList;
                upperBound = currentWeight;
            }

            currentWeight -= temp;

            //update

            return;
        }  // if ..complete path

        if (!promising(permLength)) {
            return;
        }  // if ..not promising

        for (size_t i = permLength; i < currentList.size(); ++i) {

            swap(currentList[permLength], currentList[i]);
            double temp = sqrt(TSPdistance(pokedex[currentList[permLength - 1]],pokedex[currentList[permLength]]));;

            currentWeight += temp;
            
            genPerms(permLength + 1);

            swap(currentList[permLength], currentList[i]);
            currentWeight -= temp;
        }  // for ..unpermuted elements
    }  // genPerms()



    void allTheWork(vector<node> &region) {
        pokedex = region;
        generateTSP();

        genPerms(1);

        print();
    }
};


#endif