// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#ifndef MAP_H
#define MAP_H

#include <limits>
#include <vector>

using namespace std;

enum class mapLocations {land, sea, coastline};

struct node {
    int x;
    int y;
    bool found = false;
    int prevNode = numeric_limits<int>::infinity();
    double weight = numeric_limits<double>::infinity();
    //weight = (x1 - x2)squared + (y1 - y2)squared
    mapLocations place;
};

inline double MSTdistance (node &node1, node &node2) {
  /*if (node1.place != node2.place) {
    if ((node1.place != mapLocations::coastline) && (node2.place != mapLocations::coastline)) {
      return numeric_limits<double>::infinity();
    }
  }*/

  if ((node1.place == mapLocations::sea) && (node2.place == mapLocations::land)) {
    return numeric_limits<double>::infinity();
  }
  if ((node1.place == mapLocations::land) && (node2.place == mapLocations::sea)) {
    return numeric_limits<double>::infinity();
  }
  
  return (((node1.x*1.0)- (node2.x*1.0)) * ((node1.x*1.0) - (node2.x*1.0))) + (((node1.y*1.0) - (node2.y*1.0)) * ((node1.y*1.0) - (node2.y*1.0)));
}

inline double TSPdistance (node &node1, node &node2) {
  return (((node1.x*1.0)- (node2.x*1.0)) * ((node1.x*1.0) - (node2.x*1.0))) + (((node1.y*1.0) - (node2.y*1.0)) * ((node1.y*1.0) - (node2.y*1.0)));
}



#endif