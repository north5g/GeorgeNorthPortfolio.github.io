// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0
#ifndef MODES_H
#define MODES_H

#include <getopt.h>
#include <cstdint>
#include <iostream>

using namespace std;

enum class pokeMode : uint8_t { MST, FASTTSP, OPTTSP };

// Print help for the user when requested.
// argv[0] is the name of the currently executing program
inline void printHelp() {
  cout << "Helpful comment HERE" << endl;
}  // printHelp()

// Finish this function, look for individual TODO comments internally.
// Process the command line; there is no return value, but the Options
// struct is passed by reference and is modified by this function to send
// information back to the calling function. 
inline void getMode(int argc, char * argv[], pokeMode &playerMode) {
  // These are used with getopt_long()
  opterr = false; // Let us handle all error output for command line options
  int choice; 
  int index = 0;
  bool modeSelected = false;
  option long_options[] = {
    // the "help" ('h') options.
    { "mode",  required_argument, nullptr, 'm'},
    { "help",   no_argument, nullptr, 'h'},
    { nullptr, 0, nullptr, '\0' },
  };  // long_options[]


  while ((choice = getopt_long(argc, argv, "m:h", long_options,
    &index)) != -1) {
    switch (choice) {

      case 'm': {
        modeSelected = true;
        string arg(optarg);
        if (arg == "MST") {
          playerMode = pokeMode::MST;
        }
        else if (arg == "FASTTSP") {
          playerMode = pokeMode::FASTTSP;
        }
        else if (arg == "OPTTSP") {
          playerMode = pokeMode::OPTTSP;
        }
        else {
          cerr << "Error: Invalid mode\n";
          exit(1);
        }
        break;
      }
      case 'h':
        printHelp(); 
        exit(0);
        break;

      default:
        cerr << "Error: Invalid command line option\n";
        exit(1);
    }  // switch ..choice
  }  // while

  if (!modeSelected) {
    cerr << "Error: No mode specified\n";
    exit(1);
  }

}  // getMode()

#endif