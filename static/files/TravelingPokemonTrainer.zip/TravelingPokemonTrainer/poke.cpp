// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0

#include "modes.h"
#include "map.h"
#include "OPTTSP.h"
#include <vector>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>
using namespace std;

int main(int argc, char *argv[]) {
    cout << std::setprecision(2); //Always show 2 decimal places
    cout << std::fixed; //Disable scientific notation for large numbers


    std::ios::sync_with_stdio(false); //significantly helps read run time
    pokeMode playerMode;
    getMode(argc, argv, playerMode);

    //playerMode is now a valid mode

    //create vector of nodes
    vector<node> region;
    int nodeCount;
    cin >> nodeCount;

    for (int i = 0; i < nodeCount; i++) {
        node insert;
        cin >> insert.x;
        cin >> insert.y;

        //check place
        if ((insert.x < 0) && (insert.y < 0)) {
            insert.place = mapLocations::sea;
        }
        else if ((insert.x == 0) && (insert.y <= 0)) {
            insert.place = mapLocations::coastline;
        }
        else if ((insert.x <= 0) && (insert.y == 0)) {
            insert.place = mapLocations::coastline;
        }
        else {
            insert.place = mapLocations::land;
        }

        region.push_back(insert);
    }


    switch (playerMode) {
        case pokeMode::MST: {
            region[0].weight = 0;
            int vectorTracker = 0;
            double vectorTrackerWeight = numeric_limits<double>::infinity();

            //step 0: other steps, but with more predictability to skip a loop
            //know that region[0] is shortest distance
            region[0].found = true;
            for (int i = 1; i < nodeCount; i++) {
                vectorTrackerWeight = MSTdistance(region[0], region[i]);
                //if new weight less, connect this to prev 
                if (vectorTrackerWeight < region[i].weight) {
                    region[i].weight = vectorTrackerWeight;
                    region[i].prevNode = 0;
                    }
            }

            //go through and find shortest limit for every node, loop
            //happens nodeCount - 1 times
            for (int i = 1; i < nodeCount; i++) { //find MST

            vectorTrackerWeight = numeric_limits<double>::infinity();

            //step 1: find smallest distance not found yet
            for (int i = 1; i < nodeCount; i++) {
                if (!region[i].found) {
                    if (region[i].weight < vectorTrackerWeight) {
                        vectorTrackerWeight = region[i].weight;
                        vectorTracker = i;
                    }
                }
            }

            //step 1.5: check path is possible
            if (vectorTrackerWeight == numeric_limits<double>::infinity()) {
                cout << "Cannot construct MST\n";
                exit(1);
            }

            //step 2: change node to found
            region[vectorTracker].found = true;

            //step 3: find new shortest distance connecting that to other nodes
            //vectorTrackerWeight is not needed now, use as flex value
            for (int i = 1; i < nodeCount; i++) {
                if (!region[i].found) {
                    vectorTrackerWeight = MSTdistance(region[vectorTracker], region[i]);
                    //if new weight less, connect this to prev 
                    if (vectorTrackerWeight < region[i].weight) {
                        region[i].weight = vectorTrackerWeight;
                        region[i].prevNode = vectorTracker;
                    }
                }
            }

            }//end of finding MST

            //final calculation
            double totalWeight = 0;
            double temp;
            for (int i = 0; i < nodeCount; i++) {
                temp = region[i].weight;
                totalWeight += sqrt(temp);
            }

            cout << totalWeight << '\n';
            //figure out how to print node connections; loop through with prev?
            for (int i = 1; i < nodeCount; i++) {
                if (i < region[i].prevNode) {
                    cout << i << ' ' << region[i].prevNode << '\n';
                }
                else {
                    cout << region[i].prevNode << ' ' << i << '\n';
                }
            }

            break;
        }

        case pokeMode::FASTTSP: {
            
            vector<int> tracker;
            tracker.resize(nodeCount);
            int vectorTracker = 0;
            double vectorTrackerWeight = numeric_limits<double>::infinity();
            tracker[0] = 1; //beginning
            tracker[1] = 0; //middle
            double currentWeight = 0;
            double totalWeight = sqrt(TSPdistance(region[0], region[1])) +
                        sqrt(TSPdistance(region[1], region[0]));

            for (int i = 2; i < nodeCount; i++) {
                //used to add every node into the vector
                for (size_t j = 0; int(j) < i; j++) {
                    currentWeight = sqrt(TSPdistance(region[j], region[i])) +
                        sqrt(TSPdistance(region[i], region[tracker[j]]));
                    currentWeight -= sqrt(TSPdistance(region[j], region[tracker[j]]));
                    if (currentWeight < vectorTrackerWeight) {
                        vectorTrackerWeight = currentWeight;
                        vectorTracker = int(j);
                    }
                }

                //update with smallest
                totalWeight += vectorTrackerWeight;
                vectorTrackerWeight = numeric_limits<double>::infinity();
                //need vectorTracker = i without disturing order
                tracker[i] = tracker[vectorTracker];
                tracker[vectorTracker] = i;
            }

            cout << totalWeight << '\n';
            int path = 0;
            for (int i = 0; i < nodeCount; i++) {
                cout << path << ' ';
                path = tracker[path];
            }

            break;
        }

        case pokeMode::OPTTSP: {
            OPTfunction tool;

            tool.allTheWork(region);

            break;
        }
    }
    return 0;
}