"""P5 REST API."""
import os

import flask


# app is a single object used by all the code modules in this package
app = flask.Flask(__name__)  # pylint: disable=invalid-name

import index.api    # noqa: E402  pylint: disable=wrong-import-position

# API blueprint
app.register_blueprint(index.api.api_bp)

app.config["INDEX_PATH"] = os.getenv("INDEX_PATH", "inverted_index_1.txt")
