"""REST API for /api/v1/ and helpers."""
from math import sqrt
import re
from flask import (
    Blueprint, jsonify, request
)

from index.config import (
    INDEX_PATH, PAGERANK_PATH, STOPWORDS_PATH
)

api_bp = Blueprint('api', __name__, url_prefix='/api/v1')


class VariableHelper():
    """Class for these annoying variables."""

    def __init__(self):
        """Init."""
        with open(INDEX_PATH, 'r', encoding='utf-8') as in_path:
            data = in_path.readlines()
            data_dict = {}

            for line in data:
                line_stripped = line.rstrip()
                line_split = line_stripped.split(" ", 1)
                data_dict[line_split[0]] = line_split[1]

            self._index = data_dict

        with open(PAGERANK_PATH, 'r', encoding='utf-8') as in_path:
            data = in_path.readlines()
            data_dict = {}

            for line in data:
                line_stripped = line.rstrip()
                line_split = line_stripped.partition(',')
                data_dict[line_split[0]] = line_split[2]

            self._pagerank = data_dict

        with open(STOPWORDS_PATH, 'r', encoding='utf-8') as in_path:
            data = in_path.readlines()

            data_list = []

            for line in data:
                line_stripped = line.rstrip()
                data_list.append(line_stripped)

            self._stopwords = data_list

    @property
    def index(self):
        """Inverted index property."""
        return self._index

    @property
    def pagerank(self):
        """Pagerank property."""
        return self._pagerank

    @property
    def stopwords(self):
        """Stopwords property."""
        return self._stopwords


variable_helper = VariableHelper()


# ==================================================================
# GET_RESOURCES ====================================================
# ==================================================================
@api_bp.route('/', methods=['GET'])
def get_resources():
    """Get available routes for API."""
    context = {
        "hits": "/api/v1/hits/",
        "url": "/api/v1/"
    }

    return jsonify(**context)


# ==================================================================
# GET_HITS =========================================================
# ==================================================================
@api_bp.route('/hits/', methods=['GET'])
def get_hits():
    """Process query."""
    query_string = get_cleaned_query()
    weight = get_weight()

    # query_string here is now a list of individual words
    context = make_context(query_string, weight)

    print(f"context: {context}")

    return jsonify(**context)


# ==================================================================
# HELPERS ==========================================================
# ==================================================================


# ==================================================================
# make_context =====================================================
# ==================================================================
def make_context(q_str, weight):
    """Make context."""
    # find all doc_ids in inv_index that contain all
    # words in the query string
    doc_ids = find_interesting_doc_ids(q_str)
    print(f"\n\nInteresting doc ids: {doc_ids}\n\n")

    if doc_ids == -1:
        return {"hits": []}

    # get the pageranks for all doc_ids found
    pagerank_dict = get_pageranks(doc_ids)

    unsorted_hits_list = []

    for doc_id in doc_ids:
        doc_score = calculate_score(q_str, weight,
                                    doc_id, float(pagerank_dict[doc_id]))

        unsorted_hits_list.append({"docid": int(doc_id),
                                  "score": doc_score})

    hits_list = sorted(unsorted_hits_list,
                       key=lambda x: x["score"], reverse=True)

    return {"hits": hits_list}


# ==================================================================
# find_interesting_doc_ids =========================================
# ==================================================================
def find_interesting_doc_ids(q_str):
    """Find doc_ids that contain all words in q_str."""
    term_dict = {}
    term_doc_id_sets = []

    # find all doc_ids that contain each term
    for term in q_str:
        inv_index_entry = variable_helper.index.get(term)

        if inv_index_entry is None:
            return -1

        term_dict[term] = inv_index_entry

    # filter out everything but the doc_ids
    for term_values in term_dict.values():
        doc_id_list = set()
        value_str_stripped = term_values.rstrip()
        value_str_split = value_str_stripped.split()

        # remove the idf
        value_str_split.pop(0)

        # print(f"\n\nvalue_str_split: {value_str_split}\n\n")

        # get all the doc_ids in string
        for idx in range(0, len(value_str_split), 3):
            doc_id = value_str_split[idx]
            doc_id_list.add(doc_id)

        term_doc_id_sets.append(doc_id_list)

    if len(term_doc_id_sets) == 0:
        return -1

    for id_set in term_doc_id_sets:
        if len(id_set) == 0:
            return -1

    final_doc_list = set.intersection(*term_doc_id_sets)

    return final_doc_list


# ==================================================================
# get_pageranks ====================================================
# ==================================================================
def get_pageranks(doc_ids):
    """Get the pagerank for all interesting doc_ids."""
    pagerank_dict = {}

    for doc_id in doc_ids:
        pagerank = variable_helper.pagerank[doc_id]

        pagerank_dict[doc_id] = pagerank

    return pagerank_dict


# ==================================================================
# calculate_score ==================================================
# ==================================================================
def calculate_score(q_str, weight, doc_id, pagerank):
    """Calculate tfidf for score."""
    # build query vector q_bar
    q_bar = build_q_bar(q_str)

    # build document vector d_bar and
    # build document vector d_norm
    d_bar, d_norm = build_d_bar(q_str, doc_id)

    # build query vector norm q_norm
    q_norm = calculate_norm(q_bar)

    # compute score
    qbar_dot_dbar = scalar_product(q_bar, d_bar)
    qnorm_dot_dnorm = q_norm * d_norm
    tfidf = qbar_dot_dbar / qnorm_dot_dnorm

    score = (weight * pagerank) + ((1 - weight) * tfidf)

    return score


# ==================================================================
# build_q_bar ======================================================
# ==================================================================
def build_q_bar(q_str):
    """Build q_bar."""
    # q_bar = [tf_1 * idf_1, tf_2 * idf_2, ...]
    q_bar = []

    for term in q_str:
        term_values = variable_helper.index[term]
        term_values_split = term_values.split()

        # get the tf and idf values
        tf_value = q_str.count(term)
        idf = float(term_values_split[0])

        tfidf = tf_value * idf

        q_bar.append(tfidf)

    return q_bar


# ==================================================================
# build_d_bar ======================================================
# ==================================================================
def build_d_bar(q_str, doc_id):
    """Build d_bar."""
    d_bar = []

    for term in q_str:
        term_values = variable_helper.index[term]
        term_values_split = term_values.split()

        # find the index of doc_id
        index = term_values_split.index(doc_id)

        # get the tf, idf, and norm values
        tf_value = int(term_values_split[index + 1])
        idf = float(term_values_split[0])

        norm = float(term_values_split[index + 2])

        tfidf = tf_value * idf

        d_bar.append(tfidf)

    return d_bar, sqrt(norm)


# ==================================================================
# calculate_norm ===================================================
# ==================================================================
def calculate_norm(vec):
    """Calculate norm of input."""
    norm_sum = 0

    for entry in vec:
        norm_sum += pow(entry, 2)

    return sqrt(norm_sum)


# ==================================================================
# get_cleaned_query ================================================
# ==================================================================
def get_cleaned_query():
    """Get query from request and clean input."""
    query_string = request.args.get('q')
    print(f"\nquery string: {query_string}\n")

    if query_string is None:
        print("returning empty string")
        return ""

    cleaned_string = clean_string(query_string)
    print(f"\nclean_string: {cleaned_string}\n")

    return cleaned_string


# ==================================================================
# get_weight =======================================================
# ==================================================================
def get_weight():
    """Return weight."""
    weight = request.args.get('w')

    if weight is None:
        weight = 0.5

    return float(weight)


# ==================================================================
# clean_string =====================================================
# ==================================================================
def clean_string(in_str):
    """Clean the input string."""
    # remove non-alphanumeric characters
    in_str = re.sub(r"[^a-zA-Z0-9 ]+", "", in_str)
    in_str = in_str.rstrip()

    # lowercase
    in_str = in_str.casefold()

    # remove extra spaces
    in_str = " ".join(in_str.split())
    in_str = re.split(r"\s+", in_str)

    # remove stopwords
    # credit: https://stackoverflow.com/questions/29771168/
    # how-to-remove-words-from-a-list-in-python
    in_str_final = \
        list(filter(lambda x: x not in variable_helper.stopwords, in_str))
    print(f"after stopwords removed: {variable_helper.stopwords}")

    return in_str_final


# ==================================================================
# clean_string =====================================================
# ==================================================================
# credit: https://stackoverflow.com/questions/66264747/how-to-calculate
# -the-dot-product-of-two-lists-without-importing-modules
def scalar_product(vec1, vec2):
    """Compute the dot product."""
    total_sum = 0
    for vec_x, vec_y in zip(vec1, vec2):
        total_sum = total_sum + (vec_x * vec_y)
    return total_sum
