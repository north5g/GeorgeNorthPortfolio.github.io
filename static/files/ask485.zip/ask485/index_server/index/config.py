"""API development configuration."""
import os
import pathlib

path_prefix = pathlib.Path('index_server/index')
index_prefix = path_prefix / 'inverted_index'

input_path = os.getenv("INDEX_PATH", "inverted_index_1.txt")

INDEX_PATH = (index_prefix / input_path).resolve()
PAGERANK_PATH = (path_prefix / 'pagerank.out').resolve()
STOPWORDS_PATH = (path_prefix / 'stopwords.txt').resolve()
