#!/usr/bin/env python3
"""Map 0."""
import sys


def count_docs():
    """Count the number of docs."""
    for _ in sys.stdin:
        print("doc", "\t1")


def main():
    """Run main."""
    count_docs()


if __name__ == "__main__":
    main()
