#!/usr/bin/env python3
"""Map 1."""
import csv
from pathlib import Path
import re
import sys

csv.field_size_limit(sys.maxsize)


# populate stopword set
stopwords = set()
with open(Path('stopwords.txt'), 'r', encoding='utf-8') as stopwords_file:
    words = stopwords_file.readlines()
    for word in words:
        stopwords.add(word.split('\n')[0])


def cleaner(row_input):
    """Clean the row according to spec.

    1. Combine both document title and document body by concatenating them,
        separated by a space.

    2. Remove non-alphanumeric characters (that also aren’t spaces)

    3. The inverted index should be case insensitive.
        Convert upper case characters to lower case using casefold().

    4. Split the text into whitespace-delimited terms.

    5. Remove stop words. We have provided a
        list of stop words in inverted_index/stopwords.txt.
    """
    to_return = [row_input[0]]

    # step 1
    combined_text = row_input[1] + " " + row_input[2]

    # step 2
    combined_text = re.sub(r"[^a-zA-Z0-9 ]+", "", combined_text)
    combined_text = combined_text.rstrip()

    # step 3
    combined_text = combined_text.casefold()

    # step 4
    combined_text = " ".join(combined_text.split())
    combined_text = re.split(r"\s+", combined_text)

    # step 5
    # credit: https://stackoverflow.com/questions/29771168/
    # how-to-remove-words-from-a-list-in-python
    combined_text = list(filter(lambda x: x not in stopwords, combined_text))

    to_return.append(combined_text)
    return to_return


# produces:
# (term, "doc_id", doc_id):     1
for csv_row in csv.reader(sys.stdin):
    cleaned_row = cleaner(csv_row)

    for word in cleaned_row[1]:
        print(f"{word} doc_id: {csv_row[0]}\t1")
