#!/usr/bin/env python3
"""Map 2."""
import sys

# produces:
# (term, "doc_id", doc_id, "tf", term_frequency):   1
# prepares for counting how many documents have term
for line in sys.stdin:
    line_stripped = line.rstrip('\n')
    line_partitioned = line_stripped.partition('\t')
    line_split = line_partitioned[0].split()

    to_print = f"{line_split[0]}\t{line_split[1]} " \
        f"{line_split[2]} tf: {line_partitioned[2]}"

    print(to_print)
