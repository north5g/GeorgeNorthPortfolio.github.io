#!/usr/bin/env python3
"""Map 3."""
import sys


# input:
# (term, "doc_id:", doc_id, "tf:", tf, "dwt:", dwt)
# produces:
# doc_id:   (term, "doc_id:", doc_id, "tf:", tf, "dwt:", dwt, "tf-idf", tf-idf)
for line in sys.stdin:
    line_stripped = line.rstrip('\n')
    line_split = line_stripped.split()

    term_freq = float(line_split[4])
    idf = float(line_split[6])

    tf_idf = term_freq * idf

    key = line_split[2]

    print(f"{key}\t{line_stripped} tf-idf: {tf_idf}")
