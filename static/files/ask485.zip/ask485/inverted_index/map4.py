#!/usr/bin/env python3
"""Map 4."""
import sys


# input:
# (term, "doc_id:", doc_id, "tf:", tf, "idf:", idf, "tf-idf", tf-idf,
#   "norm:", norm)
# produces:
# doc_id % 3: (term, "doc_id:", doc_id, "tf:", tf, "idf:",
#   idf, "tf-idf", tf-idf, "norm", norm)
for line in sys.stdin:
    line_stripped = line.rstrip('\n')
    line_split = line_stripped.split()

    hashed_key = int(line_split[2]) % 3

    print(f"{hashed_key}\t{line_stripped}")
