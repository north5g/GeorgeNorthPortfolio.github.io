#!/usr/bin/env python3
"""Map 5."""
import sys


# input:
# (term, "doc_id:", doc_id, "tf:", tf, "dwt:", dwt, "tf-idf", tf-idf,
#   "norm:", norm)
# produces:
# doc_id % 3: (term, "doc_id:", doc_id, "tf:", tf, "dwt:",
#   dwt, "tf-idf", tf-idf, "norm", norm)
for line in sys.stdin:
    line_stripped = line.rstrip('\n')

    print(line_stripped)
