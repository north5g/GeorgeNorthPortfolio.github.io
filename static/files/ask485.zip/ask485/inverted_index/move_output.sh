#!/bin/bash
set -Eeuo pipefail

cp output5/part-00000 ../index_server/index/inverted_index/inverted_index_0.txt
cp output5/part-00001 ../index_server/index/inverted_index/inverted_index_1.txt
cp output5/part-00002 ../index_server/index/inverted_index/inverted_index_2.txt