#!/usr/bin/env python3
"""
Reducer 2.

https://github.com/eecs485staff/madoop/blob/main/README_Hadoop_Streaming.md

Obtain the # docs containing term
"""
import math
import sys
import itertools

# dict used for appending keys
num_docs_dict = {}

# using a list maintains the original keys
inputs = list(sys.stdin)


def reduce_one_group(group, total_num_docs):
    """Reduce one group."""
    group_list = list(group)

    for line in group_list:
        line_stripped = line.rstrip('\n')
        line_partitioned = line_stripped.partition('\t')
        idf = math.log10(int(total_num_docs) / len(group_list))
        print(f"{line_partitioned[0]} {line_partitioned[2]} idf {idf}")


def keyfunc(line):
    """Return the key from a TAB-delimited key-value pair.

    line is:
    (term, "doc_id", doc_id, "tf", term_frequency):     1
    this reducer is grouping on term
    """
    return line.split()[0]


def main():
    """Divide sorted lines into groups that share a key."""
    with open("total_document_count.txt", 'r', encoding='utf-8') \
         as doc_count:
        num_docs = doc_count.readline()

    for _, group in itertools.groupby(inputs, keyfunc):
        reduce_one_group(group, num_docs)


if __name__ == "__main__":
    main()
