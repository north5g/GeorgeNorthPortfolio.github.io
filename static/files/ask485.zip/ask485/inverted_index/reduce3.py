#!/usr/bin/env python3
"""
Reducer 3.

https://github.com/eecs485staff/madoop/blob/main/README_Hadoop_Streaming.md
"""
import sys
import itertools

# using a list maintains the original keys
inputs = list(sys.stdin)

# input:
# doc_id: (term, "doc_id:", doc_id, "tf:", tf, "dwt:", dwt, "tf-idf", tf-idf)
# output:
# (term, "doc_id:", doc_id, "tf:", tf, "dwt:", dwt, "tf-idf", tf-idf,
#   "norm:", norm)


def reduce_one_group(group):
    """Reduce one group."""
    terms = list(group)

    norm = 0
    for line in terms:
        line_stripped = line.rstrip('\n')
        line_split = line_stripped.split()
        tf_idf = float(line_split[9])

        squared_tf_idf = pow(tf_idf, 2)
        norm += squared_tf_idf

    for line in terms:
        line_stripped = line.rstrip('\n')
        line_partitioned = line_stripped.partition('\t')
        print(f"{line_partitioned[2]} norm: {norm}")


def keyfunc(line):
    """Return the key from a TAB-delimited key-value pair."""
    return line.partition('\t')[0]


def main():
    """Divide sorted lines into groups that share a key."""
    for _, group in itertools.groupby(inputs, keyfunc):
        reduce_one_group(group)


if __name__ == "__main__":
    main()
