#!/usr/bin/env python3
"""
Reducer 3.

https://github.com/eecs485staff/madoop/blob/main/README_Hadoop_Streaming.md
"""
import bisect
import sys
import itertools

# using a list maintains the original keys
inputs = list(sys.stdin)

# input:
# doc_id % 3: (term, "doc_id:", doc_id, "tf:", tf, "idf:",
#   idf, "tf-idf", tf-idf, "norm", norm)
# output:


def organize_doc_ids(group):
    """Organize terms for segment of doc_ids."""
    sorted_list = []
    for line in group:
        line_stripped = line.rstrip('\n')
        line_partitioned = line_stripped.partition('\t')[2]
        line_split = line_partitioned.split()
        # doc_id, tf, norm
        if not sorted_list:
            idf = line_split[6]

        temp_str = f"{line_split[2]} {line_split[4]} {line_split[10]}"

        bisect.insort(sorted_list, temp_str,
                      key=lambda entry_str: entry_str[0])

    sorted_list.insert(0, idf)

    return sorted_list


def keyfunc_term(line):
    """Return term."""
    line_partitioned = line.partition('\t')[2]
    line_split = line_partitioned.split()
    return line_split[0]


def reduce_one_group(key, group):
    """Reduce one group."""
    # group is everything with the same hashed doc_id (0, 1, 2)
    # group all words within current group and organize by doc_id asc
    hashed_doc_group = list(group)

    organized_term_dict = {}
    for inner_key, inner_group in \
            itertools.groupby(hashed_doc_group, keyfunc_term):
        organized_term_dict[inner_key] = \
            organize_doc_ids(inner_group)

    for term, info in organized_term_dict.items():
        print(f"{key}\t{term} {info}")


def keyfunc(line):
    """Return the key from a TAB-delimited key-value pair."""
    return line.partition("\t")[0]


def main():
    """Divide sorted lines into groups that share a key."""
    for key, group in itertools.groupby(inputs, keyfunc):
        reduce_one_group(key, group)


if __name__ == "__main__":
    main()
