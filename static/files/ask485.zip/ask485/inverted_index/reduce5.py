#!/usr/bin/env python3
"""
Reducer 5.

https://github.com/eecs485staff/madoop/blob/main/README_Hadoop_Streaming.md

Obtain the # docs containing term
"""
import ast
import itertools
import sys


# produces:
# (term, idf, doc_id1, tf1, norm1, doc_id2, tf2, norm2, ...)


def reduce_one_group(group):
    """Reduce one group."""
    for line in group:
        line_stripped = line.rstrip('\n')
        line_partitioned = line_stripped.partition('\t')
        line_split = line_partitioned[2]
        info_split = line_split.split(" ", 1)

        term = info_split[0]
        list_str = info_split[1]
        info_list = ast.literal_eval(list_str)

        to_print = " ".join(info_list)

        print(f"{term} {to_print}")


def keyfunc(line):
    """Return the key from a TAB-delimited key-value pair."""
    return line.split()[0]


def main():
    """Divide sorted lines into groups that share a key."""
    for _, group in itertools.groupby(sys.stdin, keyfunc):
        reduce_one_group(group)


if __name__ == "__main__":
    main()
