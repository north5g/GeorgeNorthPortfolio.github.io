"""P5 SEARCH SERVER."""
import pathlib

import flask


# app is a single object used by all the code modules in this package
app = flask.Flask(__name__)  # pylint: disable=invalid-name

# app.config.from_object('search.config')

app.config['SEARCH_INDEX_SEGMENT_API_URLS'] = [
    "http://localhost:9000/api/v1/hits/",
    "http://localhost:9001/api/v1/hits/",
    "http://localhost:9002/api/v1/hits/",
]

SEARCH_ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
app.config['DATABASE_FILENAME'] = SEARCH_ROOT/'var'/'search.sqlite3'

import search.views    # noqa: E402  pylint: disable=wrong-import-position
import search.model    # noqa: E402  pylint: disable=wrong-import-position
