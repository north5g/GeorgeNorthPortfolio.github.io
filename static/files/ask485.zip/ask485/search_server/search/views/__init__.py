"""Views for P5 Search."""
from search.views.index import show_index
