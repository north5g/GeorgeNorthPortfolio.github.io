"""P5."""
import json
import threading
from heapq import merge
import bisect

import flask
from flask import request
import search
import requests

from ..model import get_db


# ==================================================================
# INDEX PAGE =======================================================
# ==================================================================
@search.app.route('/', methods=['GET'])
def show_index():
    """Display / route."""
    context = make_context()

    return flask.render_template("index.html", **context)


def make_context():
    """Make context for template."""
    q_str = request.args.get("q")
    weight = request.args.get("w")

    if q_str is None:
        q_str = ""

    if weight is None:
        weight = 0.5

    weight = float(weight)

    # get inverted index results
    # returns a list of lists of dicts [ [], [], [{ ... }] ]
    inv_index_results = get_inv_index_res(q_str, weight)

    top_ten_results = get_top_ten_res(inv_index_results)
    print(f"{top_ten_results}")

    context = {}

    context["results"] = get_db_info(top_ten_results)
    context["search_value"] = q_str
    context["weight"] = weight
    context["num_results"] = len(top_ten_results)

    return context


def get_db_info(results):
    """Get database info on the top 10 results."""
    to_return = []

    db_con = get_db()

    for item in results:
        cur = db_con.execute(
            "SELECT title, summary, url "
            "FROM Documents "
            "WHERE docid == ?",
            (item['docid'],)
        ).fetchone()

        temp_dict = {}
        if cur['url'] == '':
            temp_dict['url'] = "No url available"
        else:
            temp_dict['url'] = cur['url']

        temp_dict['title'] = cur['title']

        if cur['summary'] == '':
            temp_dict['summary'] = "No summary available"
        else:
            temp_dict['summary'] = cur['summary']

        to_return.append(temp_dict)

    return to_return


def get_top_ten_res(qeury_results):
    """Filter through all results and find the top 10."""
    # qeury_results is a list of lists of dicts [ [], [], [{ ... }] ]
    merged_results = merge(*qeury_results,
                           key=lambda entry_str: entry_str["score"])

    sorted_list = []

    for result in merged_results:
        bisect.insort(sorted_list, result,
                      key=lambda entry_str: entry_str["score"])

    top_ten = []

    if len(sorted_list) >= 10:
        for index in range(1, 11):
            top_ten.append(sorted_list[-index])
    else:
        for item in sorted_list:
            top_ten.append(item)
            top_ten.reverse()

    top_ten.sort(key=lambda entry: entry['score'], reverse=True)
    print(f"TOP TEN: {top_ten}")

    return top_ten


def get_inv_index_res(q_str, weight):
    """Query the inv_index servers."""
    payload = {"q": q_str, "w": weight}

    # create a shared dictionary for the threads to put results in
    thread_results = []
    thread_results_lock = threading.Lock()

    thread_list = []
    for url in search.app.config['SEARCH_INDEX_SEGMENT_API_URLS']:
        # make a new thread for each url request
        thread_args = (url, payload, thread_results, thread_results_lock)
        temp_thread = threading.Thread(target=make_request, args=thread_args)
        thread_list.append(temp_thread)
        temp_thread.start()

    # wait for all threads to finish
    for thread in thread_list:
        thread.join()

    return thread_results


def make_request(url, payload, thread_results, thread_results_lock):
    """Make a request to the url with payload."""
    print(f"URL: {url}")
    try:
        query_result = requests.get(url=url, params=payload, timeout=5)
    except ConnectionRefusedError as err:
        print(f"error in make_request: {err}")
        return
    except requests.exceptions.ConnectionError as err:
        print(f"error in make_request: {err}")
        return

    text = json.loads(query_result.text)
    hits_list = text["hits"]

    with thread_results_lock:
        thread_results.append(hits_list)
