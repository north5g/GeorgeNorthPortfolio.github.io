CREATE TABLE Documents (docid INT, title VARCHAR(100), summary VARCHAR(10000), PRIMARY KEY (docid));
INSERT INTO Documents (docid, title, summary) VALUES
(18629286, 'Human trafficking in Suriname', '');
INSERT INTO Documents (docid, title, summary) VALUES
(3646972, 'England, My England and Other Stories', '');
INSERT INTO Documents (docid, title, summary) VALUES
(31625462, 'Zachary Barth', '');
