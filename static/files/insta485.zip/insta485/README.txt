This is a program that creates a miniature social media website similar 
to Instagram, where users can post, comment, and interact with other 
posts, comments, and users.

This program mixes client-side programing with server-side programming, 
updating comment, like, and post data without needing a full webpage 
reload. This also allows for infinite scrolling and minimal delay. 

This project is property of the University of Michigan, as it is project 3 of 
Web Systems, EECS 485. This code should remain private, with any public 
release of this code breaking the University of Michigan's honor code. 
This code was created using the starter code provided by the University of 
Michigan and the efforts of George North and Dominick Tressler.