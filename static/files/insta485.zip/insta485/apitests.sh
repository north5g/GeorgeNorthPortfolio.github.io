#!/bin/bash

# http -a awdeorio:password "http://localhost:8000/api/v1/posts/?size=1&postid_lte=2"
# http -a awdeorio:password "http://localhost:8000/api/v1/posts/?size=-1&page=1&postid_lte=2"
# http -a awdeorio:password "http://localhost:8000/api/v1/posts/?size=1&page=2&postid_lte=2"


http -a jag:password "http://localhost:8000/api/v1/likes/?postid=4"

# http -a awdeorio:wrong "http://localhost:8000/api/v1/posts/?size=2&postid_lte=2"

# http -a awdeorio:password "http://localhost:8000/api/v1/likes/?postid=4"