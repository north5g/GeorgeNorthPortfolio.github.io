"""Insta485 package initializer."""
import flask
from flask import request, session, redirect, url_for


# app is a single object used by all the code modules in this package
app = flask.Flask(__name__)  # pylint: disable=invalid-name

# Read settings from config module (insta485/config.py)
app.config.from_object('insta485.config')

# Overlay settings read from a Python file whose path is set in the environment
# variable INSTA485_SETTINGS. Setting this environment variable is optional.
# Docs: http://flask.pocoo.org/docs/latest/config/
#
# EXAMPLE:
# $ export INSTA485_SETTINGS=secret_key_config.py
app.config.from_envvar('INSTA485_SETTINGS', silent=True)

# Tell our app about views and model.  This is dangerously close to a
# circular import, which is naughty, but Flask was designed that way.
# (Reference http://flask.pocoo.org/docs/patterns/packages/)  We're
# going to tell pylint and pycodestyle to ignore this coding style violation.
import insta485.api    # noqa: E402  pylint: disable=wrong-import-position
import insta485.views  # noqa: E402  pylint: disable=wrong-import-position
import insta485.model  # noqa: E402  pylint: disable=wrong-import-position

# register the blueprints
app.register_blueprint(insta485.views.users_bp)
app.register_blueprint(insta485.views.posts_bp)
app.register_blueprint(insta485.views.accounts_bp)
app.register_blueprint(insta485.views.following_bp)
app.register_blueprint(insta485.views.likes_bp)
app.register_blueprint(insta485.views.comments_bp)

# API blueprints
app.register_blueprint(insta485.api.api_bp)


def get_bp_urls(blueprint):
    """Get all routes in a given blueprint."""
    temp_app = flask.Flask(__name__)
    temp_app.register_blueprint(blueprint)
    bp_urls = [str(p) for p in temp_app.view_functions]
    return bp_urls[1:]


# list of routes accessible by users that are not logged in
no_redirect = \
    ['accounts.accounts',
     'accounts.show_login',
     'accounts.show_create',
     'accounts.get_auth',
     'likes.edit_likes',
     'comments.edit_comments',
     'posts.edit_posts',
     'following.edit_following',
     'static',
     'get_img'
     ]

# automatically append all api routes to anon_requests
no_redirect.extend(get_bp_urls(insta485.api.api_bp))


# check if the user is logged in
# if not, redirect to login page
@app.before_request
def check_logged_in():
    """Check if the user is logged in on every page."""
    # check if API call
    if request.url.find('/api/v1/') != -1:
        return None

    # check if the user is logged in
    if ("username" not in session and
            request.endpoint not in no_redirect):

        # print('redirecting to login\n')
        return redirect(url_for('accounts.show_login'))

    return None
