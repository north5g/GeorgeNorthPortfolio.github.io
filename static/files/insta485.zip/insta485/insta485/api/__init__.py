"""Insta485 REST API."""

from insta485.api.index import (
    api_bp, get_resources,
)
from insta485.api.helpers import api_auth, api_auth_logout
from insta485.api.posts import get_posts, get_post
from insta485.api.likes import get_like, delete_like
from insta485.api.comments import make_comment, delete_comment
