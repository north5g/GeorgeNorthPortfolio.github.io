"""REST API for comments."""
from flask import jsonify, request, Response
from werkzeug.exceptions import BadRequest

from insta485.api.index import api_bp

from insta485.queries.api.likes_comments_queries import (
    make_comment_query, does_lc_id_exist_query, is_owner_of_lc_id_query,
    delete_lc_id_query
)
from insta485.api_exceptions import (
    handle_forbidden, handle_not_found, handle_bad_request
)


# ==================================================================
# MAKE_COMMENT =====================================================
# ==================================================================
@api_bp.route('/comments/', methods=['POST'])
def make_comment():
    """Make a comment on a <postid>.

    Query parameters:
    postid=<postid>
    """
    # check that query parameter was set
    if request.args.get('postid', type=int) is None:
        return handle_bad_request()

    try:
        context = make_comment_query()
    except BadRequest:
        return handle_bad_request()

    return jsonify(**context), 201


# ==================================================================
# DELETE_COMMENT ===================================================
# ==================================================================
@api_bp.route('/comments/<int:commentid>/', methods=['DELETE'])
def delete_comment(commentid):
    """Delete <commentid>."""
    # check if commentid exists
    comment_exists = \
        does_lc_id_exist_query('comments', commentid)

    if comment_exists is False:
        return handle_not_found('Not Found')

    is_owner_of_commentid = \
        is_owner_of_lc_id_query('comments', commentid)

    if is_owner_of_commentid is False:
        return handle_forbidden('Forbidden')

    delete_lc_id_query('comments', commentid)

    return Response(status=204)
