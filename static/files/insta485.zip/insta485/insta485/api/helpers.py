"""Helper functions and globals for insta485 REST API."""

from flask import request, session

from insta485.queries.general_queries import (
    check_logged_in, check_basicauth
)
from insta485.model import get_db
from insta485.exceptions import UserNotLoggedInError
from insta485.api.index import api_bp
from insta485.api_exceptions import handle_forbidden


API_STR = '/api/v1/'

# variable for keeping track of whether a session cookie or
# basicauth was used
# dictionary for "unused variable" workaround
is_logged_basicauth = {}
is_logged_basicauth['flag'] = False


# ==================================================================
# api_auth =========================================================
# ==================================================================
@api_bp.before_request
def api_auth():
    """Check if user has permissions to access api."""
    # skip auth for resource request
    if request.endpoint == 'api.get_resources':
        return None

    session_login = True
    basicauth_login = True

    # check session cookie
    try:
        check_logged_in()
    except UserNotLoggedInError:
        # print('no cookie')
        session_login = False

    database = get_db()

    # check basicauth
    try:
        check_basicauth(database, is_logged_basicauth)
    except UserNotLoggedInError:
        # print('no basicauth')
        basicauth_login = False

    if session_login is False and \
       basicauth_login is False:
        return handle_forbidden('Forbidden')

    return None


# ==================================================================
# api_auth_logout ==================================================
# ==================================================================
@api_bp.after_request
def api_auth_logout(response):
    """Check if session needs to be popped."""
    if is_logged_basicauth['flag'] is True:
        session.pop('username', None)

    return response
