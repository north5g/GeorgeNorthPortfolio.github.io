"""REST API for /api/v1/ and helpers."""
from flask import (
    Blueprint, jsonify
)


api_bp = Blueprint('api', __name__, url_prefix='/api/v1')


# ==================================================================
# GET_RESOURCES ====================================================
# ==================================================================
@api_bp.route('/', methods=['GET'])
def get_resources():
    """Get available routes for API."""
    context = {
        "comments": "/api/v1/comments/",
        "likes": "/api/v1/likes/",
        "posts": "/api/v1/posts/",
        "url": "/api/v1/"
    }

    return jsonify(**context)
