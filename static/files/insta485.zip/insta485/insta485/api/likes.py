"""REST API for likes."""
from flask import jsonify, request, Response

from insta485.api.index import api_bp

from insta485.queries.api.likes_comments_queries import (
    get_like_query, does_lc_id_exist_query, is_owner_of_lc_id_query,
    delete_lc_id_query
)
from insta485.api_exceptions import (
    handle_forbidden, handle_not_found, handle_bad_request
)


# ==================================================================
# GET_LIKE =========================================================
# ==================================================================
@api_bp.route('/likes/', methods=['POST'])
def get_like():
    """Like a post.

    Query parameters:
    postid=<postid>
    """
    print('processing like')
    # check that query parameter was set
    if request.args.get('postid', type=int) is None:
        return handle_bad_request()

    context, was_created = get_like_query()

    # if like was created, send 201 code
    if was_created is True:
        return jsonify(**context), 201

    # otherwise send 200 code
    return jsonify(**context), 200


# ==================================================================
# DELETE_LIKE ======================================================
# ==================================================================
@api_bp.route('/likes/<int:likeid>/', methods=['DELETE'])
def delete_like(likeid):
    """Delete a like."""
    # check if likeid exists
    like_exists = does_lc_id_exist_query('likes', likeid)

    if like_exists is False:
        print('returning not found!!')
        return handle_not_found('Not Found')

    is_owner_of_likeid = is_owner_of_lc_id_query('likes', likeid)

    if is_owner_of_likeid is False:
        return handle_forbidden('Forbidden')

    delete_lc_id_query('likes', likeid)

    return Response(status=204)
