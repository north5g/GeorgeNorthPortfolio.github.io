"""REST API for posts."""
from flask import jsonify, url_for
import flask
from werkzeug.exceptions import BadRequest

from insta485.api.index import api_bp

from insta485.model import get_db
from insta485.queries.general_queries import (
    api_get_return_url, check_post_exists
)
from insta485.queries.api.posts_queries import get_posts_query, get_post_query
from insta485.api.helpers import API_STR
from insta485.api_exceptions import (
    handle_bad_request, handle_not_found
)


# ==================================================================
# GET_POSTS ========================================================
# ==================================================================
@api_bp.route('/posts/', methods=['GET'])
def get_posts():
    """Get the newest 10 posts."""
    try:
        context = get_posts_query()
    except BadRequest:
        return handle_bad_request('Bad Request')

    context['url'] = api_get_return_url()

    return jsonify(**context)


# ==================================================================
# POST/POSTID/ =====================================================
# ==================================================================
@api_bp.route('/posts/<int:postid_url_slug>/', methods=['GET'])
def get_post(postid_url_slug):
    """Return post on postid.

    Need:
    comments        done
    comments_url    done
    created         done
    imgUrl          done
    likes           done
    owner           done
    ownerImgUrl     done
    ownerShowUrl    done
    postShowUrl     done
    postid          done
    url             done
    """
    print(f'postid: {postid_url_slug}')
    # check if post exists
    if check_post_exists(get_db(), postid_url_slug) is False:
        return handle_not_found('Not Found')

    context = get_post_query(postid_url_slug)
    context['comments_url'] = \
        API_STR + 'comments/?postid=' + str(postid_url_slug)
    context['ownerShowUrl'] = \
        url_for('users.user_page', user_url_slug=context['owner'])
    context['postShowUrl'] = \
        url_for('posts.show_posts', postid_url_slug=postid_url_slug)
    context['postid'] = postid_url_slug
    context['url'] = api_get_return_url()

    return flask.jsonify(**context)
