"""Exceptions for API calls."""

import werkzeug

from insta485 import app


# ==================================================================
# handle_bad_request ===============================================
# ==================================================================
@app.errorhandler(werkzeug.exceptions.BadRequest)
def handle_bad_request(err='Bad Request'):
    """Handle status 400."""
    print(err)
    return {'message': 'Bad Request', 'status_code': 400}, 400


# ==================================================================
# handle_unauthorized ==============================================
# ==================================================================
@app.errorhandler(werkzeug.exceptions.Unauthorized)
def handle_unauthorized(err='Not Authorized'):
    """Handle status 401."""
    print(err)
    return {'message': 'Not Authorized', 'status_code': 401}, 401


# ==================================================================
# handle_forbidden =================================================
# ==================================================================
@app.errorhandler(werkzeug.exceptions.Forbidden)
def handle_forbidden(err='Forbidden'):
    """Handle status 403."""
    print(err)
    return {'message': 'Forbidden', 'status_code': 403}, 403


# ==================================================================
# handle_not_found =================================================
# ==================================================================
@app.errorhandler(werkzeug.exceptions.NotFound)
def handle_not_found(err='Not Found'):
    """Handle status 404."""
    print(err)
    return {'message': 'Not Found', 'status_code': 404}, 404
