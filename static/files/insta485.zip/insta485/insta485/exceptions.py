"""Custom exceptions for p2."""


# ==================================================================
# UnknownOperationsError ===========================================
# ==================================================================
class UnknownOperationsError(Exception):
    """Raised when an unknown operation has been entered."""

    def __init__(self, message="Unknown operation requested.") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# UserNotLoggedInError =============================================
# ==================================================================
class UserNotLoggedInError(Exception):
    """Raised when operation is requested but no user is logged in."""

    def __init__(self, message="Operation request with no"
                 "user logged in.") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# FollowingError ===================================================
# ==================================================================
class FollowingError(Exception):
    """Raised when follow/unfollow operation is not allowed."""

    def __init__(self, message="Error following or unfollowing "
                 "user.") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# LikeError ========================================================
# ==================================================================
class LikeError(Exception):
    """Raised when like/unlike operation is requested, but is now allowed."""

    def __init__(self, message="Error liking or unliking post.") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# EmptyError =======================================================
# ==================================================================
class EmptyError(Exception):
    """Raised when an empty argument is given."""

    def __init__(self, message="Error creating - empty argument.") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# DeleteError ======================================================
# ==================================================================
class DeleteError(Exception):
    """Raised when logname attempts to delete unowned content."""

    def __init__(self, message="Error deleting - "
                 "logname is not owner.") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# DeleteError ======================================================
# ==================================================================
class DisallowedExtensionError(Exception):
    """Raised when uploaded file is not allowed."""

    def __init__(self, message="Error uploading - ext. not allowed") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# UserAlreadyExistsError ===========================================
# ==================================================================
class UserAlreadyExistsError(Exception):
    """Raised when created user already exists."""

    def __init__(self, message="Error creating user") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# IncorrectPasswordError ===========================================
# ==================================================================
class IncorrectPasswordError(Exception):
    """Raised when given password is incorrect."""

    def __init__(self, message="Incorrect password") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)


# ==================================================================
# NewPasswordMatchError ============================================
# ==================================================================
class NewPasswordMatchError(Exception):
    """Raised when new passwords do not match."""

    def __init__(self, message="Passwords don't match") -> None:
        """Init."""
        self.message = message
        super().__init__(self.message)
