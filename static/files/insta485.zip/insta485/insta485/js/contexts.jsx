import { createContext } from "react";

export const LikeInfoContext = createContext();
export const CommentInfoContext = createContext();
export const EventFunctions = createContext();
