import React, { useState, useCallback } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import Post from "./post/Post";

// The parameter of this function is an object with a string called url inside it.
// url is a prop for the Post component.
export default function Feed() {
  /* Display image and post owner of a single post */
  const [firstLoad, setFirstLoad] = useState(false);
  const [nextUrl, setNextUrl] = useState("/api/v1/posts/");
  const [postsList, setPostsList] = useState([]);

  const getNextPosts = useCallback(() => {
    // Call REST API to get the post's information
    fetch(nextUrl, { credentials: "same-origin" })
      .then((response) => {
        if (!response.ok) throw Error(response.statusText);

        return response.json();
      })
      .then((data) => {
        if (firstLoad === false) {
          console.log("USEEFFECT DATA:", data);

          setFirstLoad(true);
        }

        const newPosts = data.results.map((post) => (
          // console.log(postsObj)
          <Post key={post.postid} url={post.url} />
        ));

        console.log(postsList);
        setPostsList([...postsList, newPosts]);
        setNextUrl(data.next);
      })
      .catch((error) => console.log(error));
  }, [firstLoad, nextUrl, postsList]);

  if (firstLoad === false) {
    getNextPosts();
    return <div> Loading ... </div>;
  }

  let hasMorePosts;
  if (nextUrl === "") {
    hasMorePosts = false;
  } else {
    hasMorePosts = true;
  }

  console.log("LIST POSTS", postsList);
  return (
    <InfiniteScroll
      dataLength={postsList.length}
      next={getNextPosts}
      hasMore={hasMorePosts}
      endMessage={<div style={{ textAlign: "center" }}>hoopla</div>}
    >
      {postsList}
    </InfiniteScroll>
  );
}
