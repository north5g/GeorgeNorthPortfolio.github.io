import React, { useState, useEffect, useCallback, useMemo } from "react";
import PropTypes from "prop-types";

// contexts
import {
  LikeInfoContext,
  CommentInfoContext,
  EventFunctions,
} from "../../contexts";

// components
import PostHeader from "./postHeader/PostHeader";
import PostImg from "./postImg/PostImg";
import PostStats from "./postStats/PostStats";
import PostComments from "./postComments/PostComments";

// The parameter of this function is an object with a string called url inside it.
// url is a prop for the Post component.
export default function Post({ url }) {
  /* Display a single post */

  // isLoaded is used to delay rendering until the fetch promise
  // has been resolved
  const [isLoaded, setIsLoaded] = useState(false);
  const [postInfo, setPostInfo] = useState(null);

  // EVENT HANDLERS ==============================================

  const handleLikeDoubleClick = useCallback(() => {
    if (postInfo.likes.lognameLikesThis === false) {
      const makeLikeUrl = `/api/v1/likes/?postid=${postInfo.postid}`;

      fetch(makeLikeUrl, {
        credentials: "same-origin",
        method: "POST",
      })
        .then((response) => {
          if (!response.ok) {
            throw Error(response.statusText);
          }

          // update postInfo if like was created
          return response.json();
          // TODO what do we do if we get 200? (like already exists)
        })
        .then((data) => {
          setPostInfo({
            ...postInfo,
            likes: {
              lognameLikesThis: true,
              numLikes: postInfo.likes.numLikes + 1,
              url: data.url,
            },
          });
        })
        .catch((error) => console.log(error));
    }
  }, [postInfo]);

  // event handler for like/unlike button on click
  const handleLikeUnlikeOnClick = useCallback(() => {
    // delete the like
    if (postInfo.likes.lognameLikesThis === true) {
      fetch(postInfo.likes.url, {
        credentials: "same-origin",
        method: "DELETE",
      })
        .then((response) => {
          // response.ok is a boolean set to true if the status was in
          // the 200-299 range
          if (!response.ok && response.status !== 404) {
            throw Error(response.statusText);
          }

          setPostInfo({
            ...postInfo,
            likes: {
              lognameLikesThis: false,
              numLikes: postInfo.likes.numLikes - 1,
              url: null,
            },
          });
        })
        .catch((error) => console.log(error));
    }
    // add a like
    else {
      const makeLikeUrl = `/api/v1/likes/?postid=${postInfo.postid}`;

      fetch(makeLikeUrl, {
        credentials: "same-origin",
        method: "POST",
      })
        .then((response) => {
          if (!response.ok) {
            throw Error(response.statusText);
          }

          // update postInfo if like was created
          return response.json();

          // TODO what do we do if we get 200? (like already exists)
        })
        .then((data) => {
          setPostInfo({
            ...postInfo,
            likes: {
              lognameLikesThis: true,
              numLikes: postInfo.likes.numLikes + 1,
              url: data.url,
            },
          });
        })
        .catch((error) => console.log(error));
    }
  }, [postInfo]);

  // finds index of comment id in postInfo.comment array
  function removeCommentID(commentArray, id) {
    const len = commentArray.length;
    for (let i = 0; i < len; i += 1) {
      if (commentArray[i].commentid === id) {
        commentArray.splice(i, 1);
        break;
      }
    }
  }

  // event handler for deleting comment
  const handleCommentDelete = useCallback(
    (e) => {
      e.preventDefault();

      // e.target.value contains the delete url for the comment
      fetch(e.target.value, {
        credentials: "same-origin",
        method: "DELETE",
      })
        .then((response) => {
          // response.ok is a boolean set to true if the status was in
          // the 200-299 range
          if (!response.ok) {
            throw Error(response.statusText);
          }

          const commentsCopy = [...postInfo.comments];
          removeCommentID(commentsCopy, parseInt(e.target.name, 10));

          // update state
          setPostInfo({
            ...postInfo,
            comments: commentsCopy,
          });
        })
        .catch((error) => console.log(error));
    },
    [postInfo]
  );

  // event handler for making new comment
  const handleNewComment = useCallback(
    (e) => {
      e.preventDefault();

      const form = e.target;
      const formData = new FormData(form);

      fetch(postInfo.comments_url, {
        credentials: "same-origin",
        method: "POST",
        body: JSON.stringify({ text: formData.get("text") }),
      })
        .then((response) => {
          if (!response.ok) {
            throw Error(response.statusText);
          }

          return response.json();
        })
        .then((data) => {
          setPostInfo({
            ...postInfo,
            comments: [...postInfo.comments, data],
          });
        })
        .catch((error) => console.log(error));

      e.target.reset();
    },
    [postInfo]
  );

  const eventHandlerFunctions = useMemo(
    () => ({
      likeUnlikeButton: handleLikeUnlikeOnClick,
      doubleClickLike: handleLikeDoubleClick,
      commentDelete: handleCommentDelete,
      newComment: handleNewComment,
    }),
    [
      handleLikeUnlikeOnClick,
      handleLikeDoubleClick,
      handleCommentDelete,
      handleNewComment,
    ]
  );

  useEffect(() => {
    // Declare a boolean flag that we can use to cancel the API request.
    let ignoreStaleRequest = false;
    setIsLoaded(false);

    // Call REST API to get the post's information
    fetch(url, { credentials: "same-origin" })
      .then((response) => {
        if (!response.ok) {
          throw Error(response.statusText);
        }
        // console.log('RESPONSE:', response);

        return response.json();
      })
      .then((data) => {
        // If ignoreStaleRequest was set to true, we want to ignore the results of the
        // the request. Otherwise, update the state to trigger a new render.
        if (!ignoreStaleRequest) {
          setPostInfo(data);
          // console.log('POST INFO:', data);
          setIsLoaded(true);
        }
      })
      .catch((error) => console.log(error));

    return () => {
      // This is a cleanup function that runs whenever the Post component
      // unmounts or re-renders. If a Post is about to unmount or re-render, we
      // should avoid updating state.
      ignoreStaleRequest = true;
    };
  }, [url]);

  if (isLoaded === false) {
    return <div> Loading ... </div>;
  }

  // Render post image and post owner
  return (
    <EventFunctions.Provider value={eventHandlerFunctions}>
      <div className="post">
        {/* POST HEADER */}
        <PostHeader
          owner={postInfo.owner}
          timestamp={postInfo.created}
          ownerShowUrl={postInfo.ownerShowUrl}
          ownerImgUrl={postInfo.ownerImgUrl}
          postShowUrl={postInfo.postShowUrl}
        />

        {/* POST IMG */}
        <PostImg imgUrl={postInfo.imgUrl} />

        {/* POST STATS */}
        <LikeInfoContext.Provider value={postInfo.likes}>
          <PostStats numLikes={postInfo.likes.numLikes} />
        </LikeInfoContext.Provider>

        {/* POST COMMENTS */}
        <CommentInfoContext.Provider value={postInfo}>
          <PostComments />
        </CommentInfoContext.Provider>
      </div>
    </EventFunctions.Provider>
  );
}

Post.propTypes = {
  url: PropTypes.string.isRequired,
};
