import React, { useContext } from "react";
import PostCommentsForm from "./PostCommentsForm";
import PostCommentsDelete from "./PostCommentsDelete";

import { CommentInfoContext } from "../../../contexts";

// The parameter of this function is an object with a string called url inside it.
// url is a prop for the Post component.
export default function PostComments() {
  /* Display comment and commenter's username */
  // Need:
  // comments array

  const { comments } = useContext(CommentInfoContext);

  return (
    <>
      <table className="post-comments-table">
        {comments.map((comment) => (
          <tbody key={comment.commentid}>
            <tr className="post-comments-row">
              <td className="post-comment-username-col">
                <a
                  href={comment.ownerShowUrl}
                  className="post-comment-username-text"
                >
                  {comment.owner}
                </a>
              </td>

              <td className="comment-text">{comment.text}</td>

              <td>
                {comment.lognameOwnsThis && (
                  <PostCommentsDelete
                    id={comment.commentid}
                    url={comment.url}
                  />
                )}
              </td>
            </tr>
          </tbody>
        ))}
      </table>

      <div className="post-add-comment">
        <PostCommentsForm />
      </div>
    </>
  );
}
