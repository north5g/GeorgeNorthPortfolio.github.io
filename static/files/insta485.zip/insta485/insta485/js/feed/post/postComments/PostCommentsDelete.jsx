import React, { useContext } from "react";
import PropTypes from "prop-types";

import { EventFunctions } from "../../../contexts";

export default function PostCommentsDelete({ id, url }) {
  // like/unlike button for post's likes

  const onClick = useContext(EventFunctions).commentDelete;

  return (
    <button
      className="delete-comment-button"
      type="submit"
      name={id}
      value={url}
      onClick={onClick}
    >
      Delete comment
    </button>
  );
}

PostCommentsDelete.propTypes = {
  id: PropTypes.number.isRequired,
  url: PropTypes.string.isRequired,
};
