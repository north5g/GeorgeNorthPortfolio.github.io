import React, { useContext } from "react";

import { EventFunctions } from "../../../contexts";

export default function PostCommentsForm() {
  // like/unlike button for post's likes

  const onSubmit = useContext(EventFunctions).newComment;

  return (
    <form className="comment-form" onSubmit={onSubmit}>
      {/* // <form className="comment-form" onSubmit={e => {e.preventDefault(); console.log(e);}}> */}
      <input className="comment-text" type="text" name="text" />
      {/* <button className="" onClick={onClick}>unlike</button> */}
    </form>
  );
}
