import React from "react";
import PropTypes from "prop-types";
import moment from "moment";

export default function PostHeader({
  owner,
  timestamp,
  ownerShowUrl,
  ownerImgUrl,
  postShowUrl,
}) {
  /* Render the post's header */
  // Needs:
  // postInfo.owner
  // postInfo.created
  // postInfo.ownerShowUrl
  // postInfo.ownerImgUrl
  // postInfo.postShowUrl

  const created = moment(timestamp, "YYYY-MM-DD HH:mm:ss", true);
  const now = moment.utc(new Date()).format("YYYY-MM-DD HH:mm:ss");
  const timePassed = moment.duration(created.diff(now)).humanize();

  return (
    <div className="post-header">
      {/* user image */}
      <a href={ownerShowUrl}>
        <img className="post-header-img" src={ownerImgUrl} alt={ownerShowUrl} />
      </a>

      {/* username */}
      <a href={ownerShowUrl} className="post-header-username">
        {owner}
      </a>

      {/* timestamp */}
      <a href={postShowUrl} className="post-header-timestamp">
        {timePassed}
      </a>
    </div>
  );
}

PostHeader.propTypes = {
  owner: PropTypes.string.isRequired,
  timestamp: PropTypes.string.isRequired,
  ownerShowUrl: PropTypes.string.isRequired,
  ownerImgUrl: PropTypes.string.isRequired,
  postShowUrl: PropTypes.string.isRequired,
};
