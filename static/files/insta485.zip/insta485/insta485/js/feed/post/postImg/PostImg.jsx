import React, { useContext } from "react";
import PropTypes from "prop-types";

import { EventFunctions } from "../../../contexts";

export default function PostImg({ imgUrl }) {
  /* Render the post's img */
  // Need:
  // postInfo.imgUrl

  const onDoubleClick = useContext(EventFunctions).doubleClickLike;

  // Render post image and post owner
  return (
    <div className="post-img-box">
      <img
        className="post-img"
        src={imgUrl}
        alt="img"
        onDoubleClick={onDoubleClick}
      />
    </div>
  );
}

PostImg.propTypes = {
  imgUrl: PropTypes.string.isRequired,
};
