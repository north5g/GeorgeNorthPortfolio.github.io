import React from "react";
import PropTypes from "prop-types";
import PostStatsButton from "./PostStatsButton";

export default function PostStats({ numLikes }) {
  /* Render the post's stats */
  // Need:
  // postInfo.numLikes

  // Render post image and post owner
  return (
    <div className="post-stats-box">
      <span className="post-stats-likes">
        {numLikes === 1 ? `${numLikes} like` : `${numLikes} likes`}
      </span>

      <div className="post-like-unlike-button">
        <PostStatsButton />
      </div>
    </div>
  );
}

PostStats.propTypes = {
  numLikes: PropTypes.number.isRequired,
};
