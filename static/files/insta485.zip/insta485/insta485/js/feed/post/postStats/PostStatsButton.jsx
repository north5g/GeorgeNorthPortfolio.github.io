import React, { useContext } from "react";

// contexts
import { LikeInfoContext, EventFunctions } from "../../../contexts";

export default function PostStatsButton() {
  // like/unlike button for post's likes
  // Needs:
  // lognameLikesThis

  const { lognameLikesThis } = useContext(LikeInfoContext);
  const onClick = useContext(EventFunctions).likeUnlikeButton;

  const className = "like-unlike-button";

  return (
    <div>
      {lognameLikesThis === true ? (
        <button type="submit" className={className} onClick={onClick}>
          unlike
        </button>
      ) : (
        <button type="submit" className={className} onClick={onClick}>
          like
        </button>
      )}
    </div>
  );
}
