"""Insta485 model (database) queries for /accounts/."""

from flask import session, request
from markupsafe import escape

from .. import model

from insta485.queries.general_queries import *
from insta485 import exceptions


# ==================================================================
# LOGIN ENDPOINT ===================================================
# ==================================================================
def login_query():
    """Login user."""
    db = model.get_db()

    username = escape(request.form.get('username'))

    # check if the user doesn't exist
    res = db.execute(
        "SELECT COUNT(*) AS count "
        "FROM users "
        "WHERE username == ?",
        (username,)
    ).fetchone()

    if res['count'] == 0:
        # should have its own exception, but it results in the same abort
        # so whatever lol
        raise exceptions.IncorrectPasswordError

    username = request.form.get('username')
    password = request.form.get('password')

    result = check_password(db, username, password)

    if result is False:
        raise exceptions.IncorrectPasswordError


# ==================================================================
# CREATE ENDPOINT ==================================================
# ==================================================================
def create_query():
    """Create user."""
    db = model.get_db()

    username = escape(request.form.get('username'))

    # check if the user already exists
    res = db.execute(
        "SELECT COUNT(*) AS count "
        "FROM users "
        "WHERE username == ?",
        (username,)
    ).fetchone()

    if res['count'] == 1:
        raise exceptions.UserAlreadyExistsError

    password = escape(request.form.get('password'))
    fullname = escape(request.form.get('fullname'))
    email = escape(request.form.get('email'))

    hashed_filename = process_submitted_img()

    # generate password hash
    hashed_password = generate_sha512(password)

    # create database entry for user
    db.execute(
        "INSERT INTO users(username, fullname, email, filename, password) "
        "VALUES (?, ?, ?, ?, ?)",
        (username, fullname, email, hashed_filename, hashed_password)
    )


# ==================================================================
# DELETE ENDPOINT ==================================================
# ==================================================================
def delete_query():
    """Delete user."""
    check_logged_in()

    db = model.get_db()

    # go through each post and delete each image from filesystem
    cur = db.execute(
        "SELECT filename "
        "FROM posts "
        "WHERE owner == ?",
        (session['username'],)
    ).fetchall()

    for post in cur:
        path = UPLOAD_FOLDER / post['filename']
        path.unlink()

    # delete user icon
    delete_current_img(db)

    db.execute(
        "DELETE FROM users "
        "WHERE username == ?",
        (session['username'],)
    )

    session.pop('username', None)


# ==================================================================
# EDIT ENDPOINT ====================================================
# ==================================================================
def edit_endpoint_query():
    """Edit user."""
    check_logged_in()

    db = model.get_db()

    hashed_filename = None
    # update user's photo if provided
    if request.files['file'].filename != '':
        delete_current_img(db)
        hashed_filename = process_submitted_img()

    # update fullname and email
    fullname = escape(request.form['fullname'])
    email = escape(request.form['email'])

    # save the changes to the database
    edit_endpoint_helper_q(db, hashed_filename, fullname, email)


# ==================================================================
# EDIT PAGE ========================================================
# ==================================================================
def edit_page_query():
    """Build context for edit page with database.

    Need:
    owner_img_url
    cur_fullname
    cur_email
    """
    db = model.get_db()

    cur = db.execute(
        "SELECT fullname, email "
        "FROM users "
        "WHERE username == ?",
        (session['username'],)
    ).fetchone()

    context = {}

    context['owner_img_url'] = get_user_filename_q(db, session['username'])
    context['fullname'] = cur['fullname']
    context['email'] = cur['email']
    context['username'] = session['username']

    return context


# ==================================================================
# UPDATE ENDPOINT ==================================================
# ==================================================================
def update_endpoint_query():
    """Update password."""
    check_logged_in()

    db = model.get_db()

    password_check = \
        check_password(db, session['username'], request.form['password'])

    if password_check is False:
        raise exceptions.IncorrectPasswordError

    if request.form['new_password1'] != request.form['new_password2']:
        raise exceptions.NewPasswordMatchError

    # set new password
    new_pw_hash = generate_sha512(request.form['new_password1'])
    db.execute(
        "UPDATE users "
        "SET password = ? "
        "WHERE username == ?",
        (new_pw_hash, session['username'])
    )

# HELPERS ==========================================================


def process_submitted_img():
    """Save submitted image, generate uuid name, return name."""
    file = request.files['file']
    filename = escape(file.filename)

    # save the image
    hashed_filename = upload_img_q(filename)

    return hashed_filename


def delete_current_img(db):
    """Delete current user img."""
    cur = db.execute(
        "SELECT filename "
        "FROM users "
        "WHERE username == ?",
        (session['username'],)
    ).fetchone()

    path = UPLOAD_FOLDER / cur['filename']
    path.unlink()


def edit_endpoint_helper_q(db, hashed_filename, fullname, email):
    """Update information."""
    # update, including new file
    if hashed_filename is not None:
        db.execute(
            "UPDATE users "
            "SET fullname = ?, email = ?, filename = ? "
            "WHERE username == ?",
            (fullname, email, hashed_filename, session['username'])
        )
    # update without new file
    else:
        db.execute(
            "UPDATE users "
            "SET fullname = ?, email = ? "
            "WHERE username == ?",
            (fullname, email, session['username'])
        )
