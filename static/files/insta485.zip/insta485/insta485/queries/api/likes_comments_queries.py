"""Insta485 model (database) API queries for /likes/."""

from flask import session, request
from werkzeug.exceptions import BadRequest
import json

from insta485.exceptions import *
from insta485.model import get_db

from insta485.queries.general_queries import *
from insta485.api.helpers import API_STR


# ==================================================================
# get_like_query ===================================================
# ==================================================================
def get_like_query():
    """Make like for postid in query parameter."""
    context = {}

    db = get_db()

    postid = request.args.get('postid', type=int)

    get_like_sql = "SELECT likeid " \
        "FROM likes " \
        "WHERE owner == ? AND " \
        "postid == ?"

    # check if the like exists
    cur = db.execute(
        get_like_sql,
        (session['username'], postid)
    ).fetchone()

    # return the like if it exists and False, indicating it was not created
    if cur is not None:
        context['likeid'] = cur['likeid']
        # make url
        context['url'] = API_STR + 'likes/' + str(context['likeid']) + '/'
        return context, False

    db.execute(
        "INSERT INTO likes(owner, postid) "
        "VALUES (?, ?)",
        (session['username'], postid)
    )

    cur2 = db.execute(
        get_like_sql,
        (session['username'], postid)
    ).fetchone()

    context['likeid'] = cur2['likeid']

    # make url
    context['url'] = API_STR + 'likes/' + str(context['likeid']) + '/'

    # return the likeid and True, indicating it had to be made
    return context, True


# ==================================================================
# make_comment_query ===============================================
# ==================================================================
def make_comment_query():
    """Make comment on postid."""
    db = get_db()

    context = {}

    postid = request.args.get('postid', type=int)
    text = json.loads(request.data)['text']

    if text is None or \
       text == '':
        raise BadRequest

    db.execute(
        "INSERT INTO comments(owner, postid, text) "
        "VALUES (?, ?, ?)",
        (session['username'], postid, text)
    )

    cur = db.execute(
        "SELECT last_insert_rowid() AS commentid"
    ).fetchone()

    context['commentid'] = cur['commentid']
    context['lognameOwnsThis'] = True
    context['owner'] = session['username']
    context['ownerShowUrl'] = '/users/' + session['username'] + '/'
    context['text'] = text
    context['url'] = API_STR + 'comments/' + str(cur['commentid']) + '/'

    return context


# ==================================================================
# does_lc_id_exist_query ===========================================
# ==================================================================
def does_lc_id_exist_query(table, id):
    """Check if likeid/commentid exists."""
    db = get_db()

    if table == 'likes':
        cur = db.execute(
            "SELECT COUNT(*) AS count "
            "FROM likes "
            "WHERE likeid == ?",
            (id,)
        ).fetchone()
    elif table == 'comments':
        cur = db.execute(
            "SELECT COUNT(*) AS count "
            "FROM comments "
            "WHERE commentid == ?",
            (id,)
        ).fetchone()

    if cur['count'] == 0:
        return False

    return True


# ==================================================================
# is_owner_of_lc_id_query ==========================================
# ==================================================================
def is_owner_of_lc_id_query(table, id):
    """Return if logname owns likeid."""
    db = get_db()

    if table == 'likes':
        cur = db.execute(
            "SELECT owner "
            "FROM likes "
            "WHERE likeid == ?",
            (id,)
        ).fetchone()
    elif table == 'comments':
        cur = db.execute(
            "SELECT owner "
            "FROM comments "
            "WHERE commentid == ?",
            (id,)
        ).fetchone()

    if cur['owner'] != session['username']:
        return False

    return True


# ==================================================================
# delete_lc_id_query ===============================================
# ==================================================================
def delete_lc_id_query(table, id):
    """Return if logname owns likeid."""
    db = get_db()

    if table == 'likes':
        db.execute(
            "DELETE FROM likes "
            "WHERE likeid == ?",
            (id,)
        )
    elif table == 'comments':
        db.execute(
            "DELETE FROM comments "
            "WHERE commentid == ?",
            (id,)
        )
