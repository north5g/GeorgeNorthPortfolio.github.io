"""Insta485 model (database) API queries for /posts/."""

from flask import session, request, url_for
from werkzeug.exceptions import BadRequest

from insta485.exceptions import *
from insta485.model import get_db

from insta485.queries.general_queries import *
from insta485.api.helpers import API_STR


# ==================================================================
# POSTS ============================================================
# ==================================================================
def get_posts_query():
    """Return posts for user."""
    next, post_list = api_get_following_postids_q()

    context = {}
    context['next'] = next
    context['results'] = post_list

    return context


# ==================================================================
# POST/POSTID/ =====================================================
# ==================================================================
def get_post_query(postid):
    """Get info for postid."""
    db = get_db()

    context = {}
    context['comments'] = api_get_comments_q(postid)

    post_info = get_post_info_q(db, postid)

    context['created'] = post_info['created']
    context['imgUrl'] = str(post_info['filename'])
    context['owner'] = post_info['owner']
    context['ownerImgUrl'] = \
        str(get_user_filename_q(db, post_info['owner']))

    context['likes'] = get_likes_info_q(db, postid)

    return context


# HELPERS ==========================================================


def api_get_following_postids_q():
    """Get posts for user based on query parameters.

    Query parameters:
    ?postid_lte=N:  request results no newer than postid
                    (only show postids lte N)
    ?size=N:        request specific number of posts
    ?page=N:        request specific page (page is 0 indexed!!!!!)
    """
    db = get_db()

    # get most recent post
    most_recent = db.execute(
        "SELECT postid "
        "FROM posts "
        "ORDER BY postid DESC "
        "LIMIT 1 "
    ).fetchone()['postid']

    postid_lte = request.args.get('postid_lte', default=most_recent, type=int)
    size = request.args.get('size', default=10, type=int)
    page = request.args.get('page', default=0, type=int)
    offset = size * page
    args = [postid_lte, size, offset]

    if page < 0 or \
       size < 0:
        raise BadRequest

    # get all users logname is following
    users_following = get_following_q(db, session['username'])

    postid_list = api_get_posts(db, users_following, args)

    # add post url to each postid entry
    for entry in postid_list:
        postid = entry['postid']

        url = '/api/v1/posts/' + str(postid) + '/'

        entry['url'] = url

    next = api_make_next_url(len(postid_list), postid_lte, size, page)

    return next, postid_list


# ==================================================================
# api_get_posts ====================================================
# ==================================================================
def api_get_posts(db, users_following, args):
    """Get posts for user given args."""
    # put all user names in a list
    user_list = [session['username']]
    for user in users_following:
        user_list.append(user['username'])

    query_args = []
    query_args.extend(user_list)
    query_args.extend(args)

    # get postids
    cur = db.execute(
        "SELECT postid "
        "FROM posts "
        "WHERE owner IN ({seq}) AND "
        "postid <= ? "
        "ORDER BY postid DESC "
        "LIMIT ? OFFSET ?".format(
            seq=','.join(['?'] * len(user_list))
        ),
        (query_args)
    ).fetchall()

    return cur


# ==================================================================
# api_make_next_url ================================================
# ==================================================================
def api_make_next_url(num_posts, postid_lte, size, page):
    """Make 'next' url."""
    if num_posts < size:
        return ''

    next = request.path

    next = next + '?size=' + str(size)
    next = next + '&page=' + str(page + 1)
    next = next + '&postid_lte=' + str(postid_lte)

    return next


# ==================================================================
# api_get_comments_q ================================================
# ==================================================================
def api_get_comments_q(postid):
    """Get comments for postid."""
    db = get_db()

    cur = db.execute(
        "SELECT commentid, owner, text "
        "FROM comments "
        "WHERE postid == ?",
        (postid,)
    ).fetchall()

    for comment in cur:
        comment['lognameOwnsThis'] = False
        if comment['owner'] == session['username']:
            comment['lognameOwnsThis'] = True

        comment['ownerShowUrl'] = \
            url_for('users.user_page', user_url_slug=comment['owner'])

        comment['url'] = \
            API_STR + 'comments/' + str(comment['commentid']) + '/'

    return cur


# ==================================================================
# get_likes_info_q ==================================================
# ==================================================================
def get_likes_info_q(db, postid):
    """Get like info for postid."""
    num_likes = get_num_likes_q(db, postid)
    logname_liked = get_if_user_liked_q(db, postid, session['username'])

    like = {}
    if logname_liked:
        like['lognameLikesThis'] = True

        cur = db.execute(
            "SELECT likeid "
            "FROM likes "
            "WHERE postid == ? AND "
            "owner == ?",
            (postid, session['username'])
        ).fetchone()

        like['url'] = API_STR + 'likes/' + str(cur['likeid']) + '/'
    else:
        like['lognameLikesThis'] = False
        like['url'] = None
    like['numLikes'] = num_likes

    return like
