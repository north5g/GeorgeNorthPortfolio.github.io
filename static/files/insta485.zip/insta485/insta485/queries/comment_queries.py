"""Insta485 model (database) queries for /comments/."""

from flask import session, request
from markupsafe import escape

from .. import exceptions
from .. import model

from insta485.queries.general_queries import *


# ==================================================================
# COMMENT ==========================================================
# ==================================================================
def comment_query(operation):
    """Make or delete a comment."""
    check_logged_in()

    db = model.get_db()

    if operation == 'create':
        # check if text is empty
        if request.form['text'] == '':
            raise exceptions.EmptyError

        db.execute(
            "INSERT INTO comments(owner, postid, text) "
            "VALUES (?, ?, ?)",
            (session['username'],
             request.form['postid'],
             escape(request.form['text']))
        )
    else:
        comment_owner = get_comment_owner_q(db, request.form['commentid'])

        # check if logname owns this comment
        if comment_owner != session['username']:
            raise exceptions.DeleteError

        db.execute(
            "DELETE FROM comments "
            "WHERE commentid == ?",
            (request.form['commentid'],)
        )


#  HELPERS =========================================================


def get_comment_owner_q(db, commentid):
    """Get comment information given commentid."""
    cur = db.execute(
        "SELECT owner "
        "FROM comments "
        "WHERE commentid == ?",
        (commentid,)
    ).fetchone()

    return cur['owner']
