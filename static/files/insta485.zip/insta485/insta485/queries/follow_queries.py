"""Insta485 model (database) queries for /follow/."""

from flask import session

from .. import model
from .. import exceptions

from insta485.queries.general_queries import is_following_q, check_logged_in


# ==================================================================
# FOLLOW AND UNFOLLOW ==============================================
# ==================================================================
def follow_user_query(operation, user_url_slug):
    """Set logname to follow or unfollow user_url_slug."""
    check_logged_in()

    db = model.get_db()

    res = {}

    # check if the user is already following user_url_slug
    res['is_following'] = \
        is_following_q(db, session['username'], user_url_slug)

    if operation == 'follow':
        if res['is_following'] == 1:
            raise exceptions.FollowingError

        add_following_q(db, session['username'], user_url_slug)
    else:
        if res['is_following'] == 0:
            raise exceptions.FollowingError

        remove_following_q(db, session['username'], user_url_slug)


# HELPERS ==========================================================

def add_following_q(db, user1, user2):
    """Add an entry into database that user1 follows user2."""
    db.execute(
        "INSERT INTO following(username1, username2) "
        "VALUES (?, ?)",
        (user1, user2)
    )


def remove_following_q(db, user1, user2):
    """Remove entry from database that user1 follows user2."""
    db.execute(
        "DELETE FROM following "
        "WHERE username1 == ? AND "
        "username2 == ?",
        (user1, user2)
    )
