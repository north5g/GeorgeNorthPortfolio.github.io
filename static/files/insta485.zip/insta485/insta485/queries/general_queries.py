"""General queries to be used in any file."""

from flask import request, session
from pathlib import Path
from markupsafe import escape
import uuid
import hashlib

from pathlib import Path
from insta485 import exceptions
from insta485.config import UPLOAD_FOLDER, ALLOWED_EXTENSIONS

img_endpoint = '/uploads/'


# ==================================================================
# check_user_exists_q ==============================================
# ==================================================================
def check_user_exists_q(db, user_url_slug):
    """Return if the user_url_slug exists."""
    cur = db.execute(
        "SELECT COUNT(*) AS is_user "
        "FROM users "
        "WHERE username == ?",
        (user_url_slug,)
    ).fetchone()

    if cur['is_user'] == 0:
        raise TypeError('Error: User does not exist')


# ==================================================================
# get_user_filename_q ==============================================
# ==================================================================
def get_user_filename_q(db, username):
    """Return the filename for user user_url_slug."""
    cur = db.execute(
        "SELECT filename "
        "FROM users "
        "WHERE username == ?",
        (username,)
    ).fetchone()

    filename = Path(img_endpoint + cur['filename'])

    return filename


# ==================================================================
# get_followers_q ==================================================
# ==================================================================
def get_followers_q(db, user_url_slug):
    """Return a list of users following user_url_slug."""
    cur = db.execute(
        "SELECT username1 AS username "
        "FROM following "
        "WHERE username2 == ?",
        (user_url_slug,)
    ).fetchall()

    return cur


# ==================================================================
# get_following_q ==================================================
# ==================================================================
def get_following_q(db, user_url_slug):
    """Return a list of users user_url_slug is following."""
    cur = db.execute(
        "SELECT username2 AS username "
        "FROM following "
        "WHERE username1 == ?",
        (user_url_slug,)
    ).fetchall()

    return cur


# ==================================================================
# is_following_q ===================================================
# ==================================================================
def is_following_q(db, user1, user2):
    """Return whether or not user1 is following user2."""
    cur = db.execute(
        "SELECT COUNT(*) AS is_following "
        "FROM following "
        "WHERE username1 == ? AND "
        "username2 == ?",
        (user1, user2)
    ).fetchone()

    return cur['is_following']


# ==================================================================
# get_num_followers_q ==============================================
# ==================================================================
def get_num_followers_q(db, user_url_slug):
    """Get the number of followers the logged-in user has."""
    res = get_followers_q(db, user_url_slug)

    return len(res)


# ==================================================================
# get_num_following_q ==============================================
# ==================================================================
def get_num_following_q(db, user_url_slug):
    """Get the number the logged-in user is following."""
    cur = db.execute(
        "SELECT COUNT(*) AS following "
        "FROM following "
        "WHERE username1 == ?",
        (user_url_slug,)
    ).fetchone()

    return cur['following']


# ==================================================================
# get_full_name ====================================================
# ==================================================================
def get_full_name(db, user_url_slug):
    """Get the full name of the user at user_url_slug."""
    cur = db.execute(
        "SELECT fullname "
        "FROM users "
        "WHERE username == ?",
        (user_url_slug,)
    ).fetchone()

    return cur['fullname']


# ==================================================================
# get_user_posts ===================================================
# ==================================================================
def get_user_posts(db, user_url_slug):
    """Get the posts made by the user to display on profile."""
    cur = db.execute(
        "SELECT postid, filename "
        "FROM posts "
        "WHERE owner == ?",
        (user_url_slug,)
    ).fetchall()

    posts = []

    for post in cur:
        # This is the URL endpoint that the browser will request the file from
        # NOT a hard-coded upload directory
        filepath = Path(img_endpoint + post['filename'])

        posts.append({
            'postid': post['postid'],
            'img_url': filepath
        })

    return posts


# ==================================================================
# get_num_likes_q ==================================================
# ==================================================================
def get_num_likes_q(db, postid):
    """Get number of likes on postid."""
    cur = db.execute(
        "SELECT COUNT(*) as num_likes "
        "FROM likes "
        "WHERE postid == ?",
        (postid,)
    ).fetchone()

    return cur['num_likes']


# ==================================================================
# get_comments_q ===================================================
# ==================================================================
def get_comments_q(db, postid):
    """Get comments for postid from oldest to newest."""
    cur = db.execute(
        "SELECT commentid, owner, text "
        "FROM comments "
        "WHERE postid == ? "
        "ORDER BY commentid ASC",
        (postid,)
    ).fetchall()

    return cur


# ==================================================================
# get_if_user_liked_q ==============================================
# ==================================================================
def get_if_user_liked_q(db, postid, user):
    """Get whether logname has liked the post or not."""
    cur = db.execute(
        "SELECT COUNT(*) AS has_liked "
        "FROM likes "
        "WHERE postid == ? AND "
        "owner == ?",
        (postid, user)
    ).fetchone()

    return cur['has_liked']


# ==================================================================
# get_all_other_users_q ============================================
# ==================================================================
def get_all_other_users_q(db, logname):
    """Get list of all users except logname."""
    cur = db.execute(
        "SELECT username "
        "FROM users "
        "WHERE username != ?",
        (logname,)
    ).fetchall()

    to_return = []
    for user in cur:
        to_return.append(user['username'])

    return to_return


# ==================================================================
# get_not_following_q ==============================================
# ==================================================================
def get_not_following_q(db, logname):
    """Get list of users logname is not following."""
    cur = db.execute(
        "SELECT others.username AS user2 "
        "FROM ("
        "SELECT username "
        "FROM users "
        "WHERE username == ?"
        ") AS logname "
        "CROSS JOIN ("
        "SELECT username "
        "FROM users "
        "WHERE username != ?"
        ") AS others "
        "WHERE (user2) NOT IN ( "
        "SELECT f.username2 "
        "FROM following AS f "
        "WHERE f.username1 == ?"
        ")",
        (logname, logname, logname)
    ).fetchall()

    # EXPLANATION:
    # Creates a cross join to enumerate all pairs that logname could follow
    # Then finds which pairs do not exist in the 'follows' table

    to_return = []
    for user in cur:
        to_return.append(user['user2'])

    return to_return


# ==================================================================
# get_post_info_q ==================================================
# ==================================================================
def get_post_info_q(db, postid_url_slug):
    """Get post info for postid_url_slug."""
    cur = db.execute(
        "SELECT * "
        "FROM posts "
        "WHERE postid == ?",
        (postid_url_slug,)
    ).fetchone()

    cur['filename'] = Path(img_endpoint + cur['filename'])

    return cur


# ==================================================================
# upload_img_q =====================================================
# ==================================================================
def upload_img_q(filename):
    """Save uploaded image."""
    # check that it's an allowed extension
    suffix = Path(filename).suffix.lower()[1:]
    if suffix not in ALLOWED_EXTENSIONS:
        raise exceptions.DisallowedExtensionError

    file = request.files['file']

    stem = uuid.uuid4().hex
    suffix = Path(filename).suffix.lower()
    uuid_basename = f'{stem}{suffix}'

    # save to disk
    file.save(UPLOAD_FOLDER/uuid_basename)

    return uuid_basename


# ==================================================================
# check_logged_in ==================================================
# ==================================================================
def check_logged_in():
    """Check if user is logged in."""
    # session cookie
    if 'username' not in session or \
            session.get('username') == '':
        print('user not logged in')
        raise exceptions.UserNotLoggedInError


# ==================================================================
# check_basic_auth =================================================
# ==================================================================
def check_basicauth(db, is_logged_basicauth):
    """Check if user is using basicauth."""
    if request.authorization is None:
        raise exceptions.UserNotLoggedInError

    username = escape(request.authorization.get('username'))
    password = escape(request.authorization.get('password'))

    if username is None or \
       password is None:
        raise exceptions.UserNotLoggedInError

    if username == '' or \
       password == '':
        raise exceptions.UserNotLoggedInError

    # check values are correct
    login_res = check_password(db, username, password)

    if login_res is False:
        raise exceptions.UserNotLoggedInError

    is_logged_basicauth['flag'] = True
    session['username'] = username


# ==================================================================
# check_password ===================================================
# ==================================================================
def check_password(db, username, password):
    """Check password."""
    # get stored hash
    stored_hash = get_pw_hash(db, username)

    stored_salt = stored_hash.rsplit('$')[1]

    generated_hash = generate_sha512(password, stored_salt)

    if stored_hash != generated_hash:
        return False

    return True


# ==================================================================
# get_pw_hash =====================================================
# ==================================================================
def get_pw_hash(db, username):
    """Get password hash for username."""
    cur = db.execute(
        "SELECT password "
        "FROM users "
        "WHERE username == ?",
        (username,)
    ).fetchone()['password']

    return cur


# ==================================================================
# generate_sha512 ==================================================
# ==================================================================
def generate_sha512(password, salt=''):
    """Generate sha512 password hash."""
    algorithm = 'sha512'

    if salt == '':
        salt = uuid.uuid4().hex

    password_salted = salt + password

    hash_obj = hashlib.new(algorithm)
    hash_obj.update(password_salted.encode('utf-8'))

    password_hash = hash_obj.hexdigest()
    password_db_string = "$".join([algorithm, salt, password_hash])

    return password_db_string


# ==================================================================
# generate_sha512 ==================================================
# ==================================================================
def api_get_return_url():
    """Get url to return in api call."""
    full = request.full_path

    if full.find('postid') == -1 and \
       full.find('page') == -1 and \
       full.find('size') == -1:
        full = full[:-1]

    return full


# ==================================================================
# check_post_exists ================================================
# ==================================================================
def check_post_exists(db, postid):
    """Check if postid exists."""
    cur = db.execute(
        "SELECT COUNT(*) as count "
        "FROM posts "
        "WHERE postid == ?",
        (postid,)
    ).fetchone()

    if cur['count'] == 0:
        return False

    return True
