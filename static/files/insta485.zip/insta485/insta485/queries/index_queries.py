"""Insta485 model (database) queries for /."""
# [1]   https://stackoverflow.com/questions/5766230/
#       select-from-sqlite-table-where-rowid-in-list-using-python
#       -sqlite3-db-api-2-0

from flask import session
import arrow
from pathlib import Path

from .. import model

from insta485.queries.general_queries import *


# ==================================================================
# INDEX PAGE =======================================================
# ==================================================================
def index_page_query():
    """Access database to build context for / route.

    Need for context:
    postid (posts)
    owner (posts)
    owner_img_url (users, join on owner=username)
    img_url (posts)
    timestamp (posts) (humanize from arrow)
    likes (likes, join on postid)
    comments (comments, join on postid)
    """
    db = model.get_db()

    context = {}
    context['posts'] = []

    # get all postsids from the users
    postids_list = get_following_postids_q(db)

    # generate a dict for each postid
    for postid in postids_list:
        temp = {}
        temp['postid'] = postid

        post_info = get_post_info_q(db, postid)

        temp['owner'] = post_info['owner']
        temp['img_url'] = Path(img_endpoint + post_info['filename'])
        temp['timestamp'] = arrow.get(post_info['created']).humanize()

        # get owner_img_url
        temp['owner_img_url'] = get_user_filename_q(db, temp['owner'])

        # get number of likes
        temp['likes'] = get_num_likes_q(db, postid)

        # get comments on postid
        temp['comments'] = get_comments_q(db, postid)

        # get whether logname has liked the post
        temp['user_liked'] = \
            get_if_user_liked_q(db, postid, session['username'])

        context['posts'].append(temp)

    return context


# ==================================================================
# EXPLORE PAGE =====================================================
# ==================================================================
def explore_page_query():
    """Build the context for /explore/ route."""
    db = model.get_db()

    context = {}
    context['not_following'] = []

    users_not_following = \
        get_not_following_q(db, session['username'])

    for user in users_not_following:
        temp = {}
        temp['username'] = user
        temp['user_img_url'] = get_user_filename_q(db, user)

        context['not_following'].append(temp)

    return context


# HELPER FUNCTIONS =================================================


def get_following_postids_q(db):
    """Get the postids of logname and followed users."""
    # get all users logname is following
    users_following = get_following_q(db, session['username'])

    # put all user names in a list
    user_list = [session['username']]
    for user in users_following:
        user_list.append(user['username'])

    # sequence code credit at the top of the file [1]
    cur = db.execute(
        "SELECT postid "
        "FROM posts "
        "WHERE owner IN ({seq}) "
        "ORDER BY postid DESC".format(
            seq=','.join(['?'] * len(user_list))
        ),
        (user_list)
    ).fetchall()

    # turn the list of dicts into a list of values
    to_return = []
    for i in cur:
        to_return.append(i['postid'])

    return to_return


def get_post_info_q(db, postid):
    """Get the record in posts corresponding to postid."""
    cur = db.execute(
        "SELECT filename, owner, created "
        "FROM posts "
        "WHERE postid == ?",
        (postid,)
    ).fetchone()

    return cur


def does_img_exist(img_name):
    """Return whether or not the image exists."""
    db = model.get_db()

    cur = db.execute(
        "SELECT COUNT(*) AS count "
        "FROM posts "
        "WHERE filename == ?",
        (img_name,)
    ).fetchone()

    return cur['count']
