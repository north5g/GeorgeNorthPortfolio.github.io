"""Insta485 model (database) queries for /likes/."""

from flask import session

from .. import exceptions
from .. import model

from insta485.queries.general_queries import (
    get_if_user_liked_q, check_logged_in
)


# ==================================================================
# LIKE AND UNLIKE ==================================================
# ==================================================================
def like_post_query(operation, postid_url_slug):
    """Set logname to like or unlike postid_url_slug."""
    check_logged_in()

    db = model.get_db()

    res = {}

    # check if the user is already following user_url_slug
    res['has_liked'] = \
        get_if_user_liked_q(db, postid_url_slug, session['username'])

    if operation == 'like':
        if res['has_liked'] == 1:
            raise exceptions.LikeError

        add_like_q(db, postid_url_slug, session['username'])
    else:
        if res['has_liked'] == 0:
            raise exceptions.LikeError

        remove_like_q(db, postid_url_slug, session['username'])


# HELPERS ==========================================================


def add_like_q(db, postid_url_slug, logname):
    """Insert like record into database."""
    db.execute(
        "INSERT INTO likes(owner, postid) "
        "VALUES (?, ?)",
        (logname, postid_url_slug)
    )


def remove_like_q(db, postid_url_slug, logname):
    """Remove like record from database."""
    db.execute(
        "DELETE FROM likes "
        "WHERE owner == ? "
        "AND postid == ?",
        (logname, postid_url_slug)
    )
