"""Insta485 model (database) queries for /posts/."""

from flask import session, request
import arrow

from markupsafe import escape


from .. import exceptions
from .. import model

from insta485.queries.general_queries import *
from insta485.config import UPLOAD_FOLDER


# ==================================================================
# POSTS ============================================================
# ==================================================================
def posts_request_query(operation):
    """Make or delete a post."""
    check_logged_in()

    if operation == 'delete':
        delete_post_helper()
        return

    # check if file is empty
    if 'file' not in request.files:
        raise exceptions.EmptyError

    filename = escape(request.files.get('file').filename)

    if filename == '':
        raise exceptions.EmptyError

    # run helper
    create_post_helper(filename)


# ==================================================================
# SHOW POSTS =======================================================
# ==================================================================
def posts_page_query(postid_url_slug):
    """Get <postid_url_slug> info.

    Need:
    postid (posts)
    owner (posts)
    img_url (posts)
    timestamp (posts)
    owner_img_url (users, join on posts.owner)
    likes (likes, join on posts.postid)
    comments (comments, join on posts.postid)
    """
    db = model.get_db()

    context = {}

    res = get_post_info_q(db, postid_url_slug)

    context['postid'] = res['postid']
    context['owner'] = res['owner']
    context['img_url'] = res['filename']
    context['timestamp'] = arrow.get(res['created']).humanize()

    context['owner_img_url'] = get_user_filename_q(db, context['owner'])

    context['likes'] = get_num_likes_q(db, postid_url_slug)

    context['comments'] = get_comments_q(db, postid_url_slug)

    context['user_liked'] = \
        get_if_user_liked_q(db, postid_url_slug, session['username'])

    return context


# HELPERS ==========================================================


# ==================================================================
# POSTS create_helper ==============================================
# ==================================================================
def create_post_helper(filename):
    """Validate post and create."""
    db = model.get_db()

    hashed_filename = upload_img_q(filename)

    insert_post_q(db, hashed_filename)


# ==================================================================
# POSTS delete_helper ==============================================
# ==================================================================
def delete_post_helper():
    """Validate request and delete."""
    db = model.get_db()

    # check if logname owns the post
    # what about posts that don't exist?
    # ^ answered on Piazza, do not need to worry
    post_info = get_post_info_q(db, request.form['postid'])

    if post_info['owner'] != session['username']:
        raise exceptions.DeleteError

    # delete post from filesystem
    filename = str(post_info['filename']).rsplit('/', 1)[1]
    path = UPLOAD_FOLDER / filename
    path.unlink()

    # delete post from database
    db.execute(
        "DELETE FROM posts "
        "WHERE postid == ?",
        (request.form['postid'],)
    )


# ==================================================================
# insert_post_q ====================================================
# ==================================================================
def insert_post_q(db, filename):
    """Create record for post."""
    db.execute(
        "INSERT INTO posts(filename, owner) "
        "VALUES (?, ?)",
        (filename, session['username'])
    )
