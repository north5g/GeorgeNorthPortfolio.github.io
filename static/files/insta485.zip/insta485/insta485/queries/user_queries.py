"""Insta485 model (database) queries for /user/."""

from flask import session

from .. import model

from insta485.queries.general_queries import *


# ==================================================================
# USER PAGE ========================================================
# ==================================================================
def user_page_query(user_url_slug):
    """Query for /user/<user_url_slug>/ context.

    Check 'following' table for:
    if (session['username'], user_url_slug) exists
    # followers (how many times session['username'] appears as username2)
    # following (how many times session['username'] appears as username1)

    Check 'users' table for:
    Full name
    """
    db = model.get_db()

    context = {}

    # check user exists
    # raises TypeValue error if user does not exist
    check_user_exists_q(db, user_url_slug)

    # get user's full name
    context['fullname'] = get_full_name(db, user_url_slug)

    # check how many posts the user has
    context['posts'] = get_user_posts(db, user_url_slug)
    context['total_posts'] = len(context['posts'])

    # check if logged-in user is following user_url_slug
    context['logname_follows_username'] = \
        is_following_q(db, session['username'], user_url_slug)

    # check how many followers logged-in user has
    context['followers'] = get_num_followers_q(db, user_url_slug)

    # check how many users logged-in user is following
    context['following'] = get_num_following_q(db, user_url_slug)

    # get all the posts made by the user
    context['posts'] = get_user_posts(db, user_url_slug)

    return context


# ==================================================================
# FOLLOWERS PAGE ===================================================
# ==================================================================
def user_page_followers_query(user_url_slug):
    """Query for /user/<user_url_slug>/followers/ context."""
    db = model.get_db()

    context = {}
    context['followers'] = []

    check_user_exists_q(db, user_url_slug)

    # get all the followers this person has
    cur = get_followers_q(db, user_url_slug)

    # populate context
    for user in cur:
        temp = {}
        temp['username'] = user['username']
        temp['user_img_url'] = get_user_filename_q(db, user['username'])
        temp['logname_follows_username'] = \
            is_following_q(db, session['username'], user['username'])

        context['followers'].append(temp)

    return context


# ==================================================================
# FOLLOWING PAGE ===================================================
# ==================================================================
def user_page_following_query(user_url_slug):
    """Query for /user/<user_url_slug>/following/ context."""
    db = model.get_db()

    context = {}
    context['following'] = []

    check_user_exists_q(db, user_url_slug)

    # get all users the person is following
    cur = get_following_q(db, user_url_slug)

    # populate context
    for user in cur:
        temp = {}
        temp['username'] = user['username']
        temp['user_img_url'] = get_user_filename_q(db, user['username'])
        temp['logname_follows_username'] = \
            is_following_q(db, session['username'], user['username'])

        context['following'].append(temp)

    return context


# HELPER FUNCTIONS =================================================
