"""Views, one for each Insta485 page."""
from insta485.views.index import show_index

# for blueprint registration
from insta485.views.users import users_bp
from insta485.views.accounts import accounts_bp
from insta485.views.following_and_likes import following_bp, likes_bp
from insta485.views.comments_and_posts import comments_bp, posts_bp
