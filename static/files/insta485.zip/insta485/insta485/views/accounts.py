"""
Insta485 accounts view.

URLs include:
/accounts/login/    GET
/accounts/logout/   POST
/accounts/create/   GET
/accounts/delete/   GET
/accounts/edit/     GET
/accounts/password/ GET
/accounts/auth/     GET
/accounts           POST operations for all above GETs
"""

from flask import (
    Blueprint, redirect, render_template, request,
    session, url_for, Response, abort
)

from insta485 import exceptions
from insta485.views.helper import context_builder_helper

from insta485.queries.account_queries import (
    edit_page_query, login_query, create_query, delete_query,
    edit_endpoint_query, update_endpoint_query
)


accounts_bp = Blueprint('accounts', __name__, url_prefix='/accounts')


# ==================================================================
# POST ENDPOINT ====================================================
# ==================================================================
@accounts_bp.route('/', methods=['POST'])
def accounts():
    """Route for post requests relating to accounts."""
    match request.form['operation']:
        case 'login':
            login_helper()
        case 'create':
            create_helper()
        case 'delete':
            delete_helper()
        case 'edit_account':
            edit_helper()
        case 'update_password':
            update_helper()
        case _:
            abort(400)

    if 'target' not in request.args or \
       request.args['target'] == '':
        return redirect('/')

    return redirect(request.args['target'])


# ==================================================================
# LOGIN PAGE =======================================================
# ==================================================================
@accounts_bp.route('/login/', methods=['GET'])
def show_login():
    """Display /accounts/login/ route."""
    if 'username' in session:
        return redirect(url_for('show_index'))

    return render_template('accounts-login.html')


# ==================================================================
# LOGOUT ENDPOINT ==================================================
# ==================================================================
@accounts_bp.route('/logout/', methods=['POST'])
def logout():
    """Log the user out."""
    session.pop('username', None)
    return redirect(url_for('accounts.show_login'))


# ==================================================================
# CREATE PAGE ======================================================
# ==================================================================
@accounts_bp.route('/create/', methods=['GET'])
def show_create():
    """Display /accounts/create/ route."""
    return render_template('accounts-create.html')


# ==================================================================
# EDIT PAGE ========================================================
# ==================================================================
@accounts_bp.route('/edit/', methods=['GET'])
def show_edit():
    """Display /accounts/edit/ route."""
    context = edit_build_context()

    return render_template('accounts-edit.html', **context)


# ==================================================================
# DELETE PAGE ======================================================
# ==================================================================
@accounts_bp.route('/delete/', methods=['GET'])
def show_delete():
    """Display /accounts/delete/ route."""
    context = {}
    context['username'] = session['username']

    context_builder_helper(context, session['username'], request.path)

    return render_template('accounts-delete.html', **context)


# ==================================================================
# PASSWORD PAGE ====================================================
# ==================================================================
@accounts_bp.route('/password/', methods=['GET'])
def show_password():
    """Display /accounts/password/ route."""
    context = {}
    context_builder_helper(context, session['username'], request.path)

    return render_template('accounts-password.html', **context)


# ==================================================================
# AUTH PAGE ========================================================
# ==================================================================
@accounts_bp.route('/auth/', methods=['GET'])
def get_auth():
    """Check if user is logged in."""
    if 'username' not in session:
        abort(403)

    return Response(status=200)


# HELPER FUNCTIONS =================================================


# ==================================================================
# EDIT PAGE ========================================================
# ==================================================================
def edit_build_context():
    """Build context for /accounts/edit/ route."""
    context = edit_page_query()

    context_builder_helper(context, session['username'], request.path)

    return context


# ==================================================================
# LOGIN ENDPOINT ===================================================
# ==================================================================
def login_helper():
    """Login helper function."""
    # check if username or password are empty
    if request.form.get('username') is None or \
       request.form.get('password') is None:
        abort(400)

    if request.form.get('username') == '' or \
       request.form.get('password') == '':
        abort(400)

    # authenticate user
    try:
        login_query()
    except exceptions.IncorrectPasswordError as err:
        print(err)
        abort(403)

    # set session cookie
    session['username'] = request.form['username']


# ==================================================================
# CREATE ENDPOINT ==================================================
# ==================================================================
def create_helper():
    """Create helper function."""
    # check if any fields are empty
    if request.form.get('username') is None or \
       request.form.get('password') is None or \
       request.form.get('fullname') is None or \
       request.form.get('email') is None or \
       'file' not in request.files:
        abort(400)

    if request.form.get('username') == '' or \
       request.form.get('password') == '' or \
       request.form.get('fullname') == '' or \
       request.form.get('email') == '' or \
       request.files['file'] == '':
        abort(400)

    # run database queries
    try:
        create_query()
    except exceptions.DisallowedExtensionError as err:
        print(err)
        abort(400)
    except exceptions.UserAlreadyExistsError as err:
        print(err)
        abort(409)

    session['username'] = request.form.get('username')


# ==================================================================
# DELETE ENDPOINT ==================================================
# ==================================================================
def delete_helper():
    """Delete helper function."""
    try:
        delete_query()
    except exceptions.UserNotLoggedInError as err:
        print(err)
        abort(403)


# ==================================================================
# EDIT ENDPOINT ====================================================
# ==================================================================
def edit_helper():
    """Edit helper function."""
    # check if any fields are empty
    if request.form.get('fullname') is None or \
       request.form.get('email') is None:
        abort(400)

    if request.form.get('fullname') == '' or \
       request.form.get('email') == '':
        abort(400)

    try:
        edit_endpoint_query()
    except exceptions.UserNotLoggedInError as err:
        print(err)
        abort(403)
    except exceptions.EmptyError as err:
        print(err)
        abort(400)


# ==================================================================
# UPDATE ENDPOINT ==================================================
# ==================================================================
def update_helper():
    """Update helper function."""
    # check if any fields are empty
    if request.form['password'] is None or \
       request.form['new_password1'] is None or \
       request.form['new_password2'] is None:
        abort(400)

    if request.form['password'] == '' or \
       request.form['new_password1'] == '' or \
       request.form['new_password2'] == '':
        abort(400)

    try:
        update_endpoint_query()
    except exceptions.UserNotLoggedInError as err:
        print(err)
        abort(403)
    except exceptions.IncorrectPasswordError as err:
        print(err)
        abort(403)
