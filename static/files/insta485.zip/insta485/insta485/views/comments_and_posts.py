"""Post endpoint controlling comments, and posts view.

URLs include:
/comments/?target=URL        POST

/posts/<postid_url_slug>/    GET
/posts/?target=URL           POST
"""

from flask import (
    Blueprint, redirect, render_template, request, session, abort
)

from insta485.queries.comment_queries import comment_query
from insta485.queries.posts_queries import (
    posts_page_query, posts_request_query
)
from insta485.views.helper import context_builder_helper
from .. import exceptions

comments_bp = Blueprint('comments', __name__, url_prefix='/comments')
posts_bp = Blueprint('posts', __name__, url_prefix='/posts')


# ==================================================================
# COMMENTS POST ENDPOINT ===========================================
# ==================================================================
@comments_bp.route('/', methods=['POST'])
def edit_comments():
    """Route for post requests relating to comments."""
    match request.form['operation']:
        case 'create':
            return comment_post_helper('comment', request.form['operation'])
        case 'delete':
            return comment_post_helper('comment', request.form['operation'])
        case _:
            abort(400)


# ==================================================================
# POSTS POST ENDPOINT ==============================================
# ==================================================================
@posts_bp.route('/', methods=['POST'])
def edit_posts():
    """Route for post requests relating to posts."""
    match request.form['operation']:
        case 'create':
            return comment_post_helper('posts', request.form['operation'])
        case 'delete':
            return comment_post_helper('posts', request.form['operation'])
        case _:
            abort(400)


# ==================================================================
# POSTS PAGE =======================================================
# ==================================================================
@posts_bp.route('/<int:postid_url_slug>/', methods=['GET'])
def show_posts(postid_url_slug):
    """Display /posts/<postid_url_slug>/ route."""
    context = posts_build_context(postid_url_slug)

    return render_template('post.html', **context)

# HELPER FUNCTIONS =================================================


# ==================================================================
# POST ENDPOINT ====================================================
# ==================================================================
def comment_post_helper(query_type, operation):
    """Run the query."""
    try:
        if query_type == 'comment':
            comment_query(operation)
        else:
            posts_request_query(operation)
    except exceptions.UserNotLoggedInError as err:
        print(f'Error caught in comment_post_helper: {err}')
        abort(403)
    except exceptions.EmptyError as err:
        print(f'Error caught in comment_post_helper: {err}')
        abort(400)
    except exceptions.DeleteError as err:
        print(f'Error caught in comment_post_helper: {err}')
        abort(403)
    except exceptions.DisallowedExtensionError as err:
        print(f'Error caught in comment_post_helper: {err}')
        abort(400)

    target = request.args.get('target')

    if target is None or \
       target == '':
        if query_type == 'comment':
            return redirect('/')

        path = '/users/' + session['username'] + '/'
        return redirect(path)

    return redirect(target)


# ==================================================================
# POSTS PAGE =======================================================
# ==================================================================
def posts_build_context(postid_url_slug):
    """Build context for /posts/<postid_url_slug>/ route."""
    context = posts_page_query(postid_url_slug)

    context_builder_helper(context, session['username'], request.path)

    return context
