"""Post endpoint controlling follows, unfollows, likes, and unlikes."""

from flask import (
    Blueprint, redirect, request, abort
)

from insta485.queries.follow_queries import follow_user_query
from insta485.queries.like_queries import like_post_query

from .. import exceptions

following_bp = Blueprint('following', __name__, url_prefix='/following')
likes_bp = Blueprint('likes', __name__, url_prefix='/likes')


# ==================================================================
# FOLLOWING POST ENDPOINT ==========================================
# ==================================================================
@following_bp.route('/', methods=['POST'])
def edit_following():
    """Route for post requests relating to accounts."""
    match request.form['operation']:
        case 'follow':
            return follow_and_like_helper(request.form['operation'])
        case 'unfollow':
            return follow_and_like_helper(request.form['operation'])
        case _:
            abort(400)


# ==================================================================
# LIKES POST ENDPOINT ==============================================
# ==================================================================
@likes_bp.route('/', methods=['POST'])
def edit_likes():
    """Route for post requests relating to likes."""
    match request.form['operation']:
        case 'like':
            return follow_and_like_helper(request.form['operation'])
        case 'unlike':
            return follow_and_like_helper(request.form['operation'])
        case _:
            abort(400)


# HELPER FUNCTIONS =================================================


def follow_and_like_helper(operation):
    """Run the query."""
    try:
        if operation in ['follow', 'unfollow']:
            follow_user_query(operation, request.form['username'])
        else:
            like_post_query(operation, request.form['postid'])
    except exceptions.UserNotLoggedInError as err:
        print(f'Error caught in follow_helper: {err}')
        abort(403)
    except exceptions.FollowingError as err:
        print(f'Error caught in follow_helper: {err}')
        abort(409)
    except exceptions.LikeError as err:
        print(f'Error caught in follow_helper: {err}')
        abort(409)

    target = request.args.get('target')

    if target is None or \
       target == '':
        return redirect('/')

    return redirect(request.args['target'])
