"""Helper functions for building contexts."""


def context_builder_helper(context, logname, cur_page_url):
    """Insert logname and current page url.

    This is used in nearly every route, and avoids code duplication.
    """
    context['logname'] = logname
    context['cur_page_url'] = cur_page_url
