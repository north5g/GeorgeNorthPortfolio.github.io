"""
Insta485 index (main) view.

URLs include:
/
"""
import flask
from flask import request, session, send_from_directory, abort

import insta485
from insta485.views.helper import context_builder_helper

from insta485.queries.index_queries import (
    index_page_query, explore_page_query, does_img_exist
)


# ==================================================================
# INDEX PAGE =======================================================
# ==================================================================
@insta485.app.route('/', methods=['GET'])
def show_index():
    """Display / route."""
    context = show_index_build_context()

    return flask.render_template("index.html", **context)


# ==================================================================
# EXPLORE PAGE =====================================================
# ==================================================================
@insta485.app.route('/explore/', methods=['GET'])
def show_explore():
    """Display /explore/ route."""
    context = show_explore_build_context()

    return flask.render_template("explore.html", **context)


# ==================================================================
# GET IMAGE ENDPOINT ===============================================
# ==================================================================
@insta485.app.route('/uploads/<img_name>')
def get_img(img_name):
    """Return requested image."""
    if 'username' not in session:
        abort(403)

    if does_img_exist(img_name) is False:
        abort(404)

    return send_from_directory(insta485.app.config['UPLOAD_FOLDER'],
                               img_name,
                               mimetype='image/gif')


# HELPER FUNCTIONS =================================================

# ==================================================================
# INDEX PAGE ===================================================
# ==================================================================
def show_index_build_context():
    """Build context for / route."""
    context = index_page_query()

    context_builder_helper(context, session['username'], request.path)

    return context


# ==================================================================
# EXPLORE PAGE =====================================================
# ==================================================================
def show_explore_build_context():
    """Build context for /explore/ route."""
    context = explore_page_query()

    context_builder_helper(context, session['username'], request.path)

    return context
