"""
Insta485 users view.

URLs include:
/accounts/login/    GET
/accounts/logout/   POST
/accounts/create/   GET
/accounts/delete/   GET
/accounts/edit/     GET
/accounts/password/ GET
/accounts/auth/     GET
/accounts           POST operations for all above GETs
"""
from markupsafe import escape

from flask import Blueprint, render_template, request, session, abort

from insta485.queries.user_queries import (
    user_page_query, user_page_followers_query, user_page_following_query
)

from insta485.views.helper import context_builder_helper

users_bp = Blueprint('users', __name__, url_prefix='/users')


# ==================================================================
# USER PAGE ========================================================
# ==================================================================
@users_bp.route('/<user_url_slug>/', methods=['GET'])
def user_page(user_url_slug):
    """Display /users/<user_url_slug>/ route."""
    context = user_page_build_context(escape(user_url_slug))

    return render_template('user.html', **context)


# ==================================================================
# FOLLOWERS PAGE ===================================================
# ==================================================================
@users_bp.route('/<user_url_slug>/followers/', methods=['GET'])
def user_followers(user_url_slug):
    """Display /users/<user_url_slug>/followers/ route."""
    context = user_followers_build_context(escape(user_url_slug))

    return render_template('followers.html', **context)


# ==================================================================
# FOLLOWING PAGE ===================================================
# ==================================================================
@users_bp.route('/<user_url_slug>/following/', methods=['GET'])
def user_following(user_url_slug):
    """Display /users/<user_url_slug>/following/ route."""
    context = user_following_build_context(escape(user_url_slug))

    return render_template('following.html', **context)


# HELPER FUNCTIONS =================================================

# ==================================================================
# USER PAGE ========================================================
# ==================================================================
def user_page_build_context(user_url_slug):
    """Build the context for /users/<user_url_slug>/ route."""
    try:
        context = user_page_query(user_url_slug)
    except TypeError as err:
        print(f'Exception caught: {err}')
        abort(404)

    context_builder_helper(context, session['username'], request.path)

    context['username'] = user_url_slug

    return context


# ==================================================================
# FOLLOWERS PAGE ===================================================
# ==================================================================
def user_followers_build_context(user_url_slug):
    """Build the context for /users/<user_url_slug>/followers/ route."""
    try:
        context = user_page_followers_query(user_url_slug)
    except TypeError as err:
        print(f'Exception caught: {err}')
        abort(404)

    context_builder_helper(context, session['username'], request.path)

    return context


# ==================================================================
# FOLLOWING PAGE ===================================================
# ==================================================================
def user_following_build_context(user_url_slug):
    """Build the context for /users/<user_url_slug>/following/ route."""
    try:
        context = user_page_following_query(user_url_slug)
    except TypeError as err:
        print(f'Exception caught: {err}')
        abort(404)

    context_builder_helper(context, session['username'], request.path)

    return context
