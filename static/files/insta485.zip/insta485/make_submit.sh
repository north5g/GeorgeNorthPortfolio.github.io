#! /bin/bash
rm submit.tar.gz

tar \
--exclude '*__pycache__*' \
-czvf submit.tar.gz \
bin \
insta485 \
package-lock.json \
package.json \
sql \
webpack.config.js \
tsconfig.json \
deployed_index.html \
deployed_index.log \
deployed_bundle.js \
deployed_bundle.log