"""Unit tests for spec REST API."""

from base64 import b64encode
import json


# ==================================================================
# test_auth_codes ==================================================
# ==================================================================
def test_auth_codes(client):
    """Test API auth codes."""    
    # test login with no credentials
    response = client.get(
        "/api/v1/posts/3/"
    )
    assert response.status_code == 403
    response_json = response.get_json()
    assert response_json == {
        "message": "Forbidden",
        "status_code": 403
    }


    # test login with wrong username:password
    wrong_creds = b64encode(b"awdeorio:wrongpw").decode('utf-8')
    response = client.get(
        "/api/v1/posts/3/",
        headers={"Authorization": f"Basic {wrong_creds}"}
    )
    assert response.status_code == 403
    response_json = response.get_json()
    assert response_json == {
        "message": "Forbidden",
        "status_code": 403
    }


    # test login with basicauth
    credentials = b64encode(b"awdeorio:password").decode('utf-8')
    response = client.get(
        "/api/v1/posts/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 200
    response_json = response.get_json()
    assert response_json == {
        "next": "",
        "results": [
            {
                "postid": 3,
                "url": "/api/v1/posts/3/"
            },
            {
                "postid": 2,
                "url": "/api/v1/posts/2/"
            },
            {
                "postid": 1,
                "url": "/api/v1/posts/1/"
            }
        ],
        "url": "/api/v1/posts/"
    }

    # test login with session cookie
    response = client.post(
        "/accounts/",
        data={
            "username": "awdeorio",
            "password": "password",
            "operation": "login"
        },
    )
    assert response.status_code == 302


    response = client.get(
        "/api/v1/posts/"
    )
    assert response.status_code == 200
    response_json = response.get_json()
    assert response_json == {
        "next": "",
        "results": [
            {
                "postid": 3,
                "url": "/api/v1/posts/3/"
            },
            {
                "postid": 2,
                "url": "/api/v1/posts/2/"
            },
            {
                "postid": 1,
                "url": "/api/v1/posts/1/"
            }
        ],
        "url": "/api/v1/posts/"
    }


# ==================================================================
# test_posts_requests ==============================================
# ==================================================================
def test_posts_requests(client):
    """Test GET /api/v1/posts/ spec requirements."""
    credentials = b64encode(b"awdeorio:password").decode('utf-8')


    # test negative page number
    response = client.get(
        "/api/v1/posts/?page=-1",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 400
    response_json = response.get_json()
    assert response_json == {
        "message": "Bad Request",
        "status_code": 400
    }


    # test negative size number
    response = client.get(
        "/api/v1/posts/?size=-1",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 400
    response_json = response.get_json()
    assert response_json == {
        "message": "Bad Request",
        "status_code": 400
    }


# ==================================================================
# test_specific_post_tests =========================================
# ==================================================================
def test_specific_post_tests(client):
    """Test GET /api/v1/posts/?postid=<postid> spec requirements."""
    credentials = b64encode(b"awdeorio:password").decode('utf-8')


    # test out of range postid
    response = client.get(
        "/api/v1/posts/1000/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 404
    response_json = response.get_json()
    assert response_json == {
        "message": "Not Found",
        "status_code": 404
    }


    # test non-int post
    # redirects due to having no actual route
    response = client.get(
        "/api/v1/posts/egg/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 404


# ==================================================================
# test_likes =======================================================
# ==================================================================
def test_likes(client):
    """Test POST and DELETE /api/v1/likes/ spec requirements."""
    credentials = b64encode(b"awdeorio:password").decode('utf-8')
    
    # like an unliked post
    response = client.post(
        "/api/v1/likes/?postid=4",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 201
    response_json = response.get_json()
    assert response_json == {
        "likeid": 7,
        "url": "/api/v1/likes/7/"
    }


    # like an already-liked post
    response = client.post(
        "/api/v1/likes/?postid=4",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 200
    response_json = response.get_json()
    assert response_json == {
        "likeid": 7,
        "url": "/api/v1/likes/7/"
    }


    # delete a like
    response = client.delete(
        "/api/v1/likes/7/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 204


    # like the post again to make sure the like was deleted
    response = client.post(
        "/api/v1/likes/?postid=4",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 201
    response_json = response.get_json()
    assert response_json == {
        "likeid": 8,
        "url": "/api/v1/likes/8/"
    }


    # re-delete the like
    response = client.delete(
        "/api/v1/likes/8/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 204


    # delete a like that does not exist
    response = client.delete(
        "/api/v1/likes/8/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 404
    response_json = response.get_json()
    assert response_json == {
        "message": "Not Found",
        "status_code": 404
    }


    # try to delete a like that is not owned
    response = client.delete(
        "/api/v1/likes/2/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 403
    response_json = response.get_json()
    assert response_json == {
        "message": "Forbidden",
        "status_code": 403
    }


# ==================================================================
# test_comments ====================================================
# ==================================================================
def test_comments(client):
    """Test POST and DELETE /api/v1/comments/ spec requirements."""
    credentials = b64encode(b"awdeorio:password").decode('utf-8')
    
    # create new comment
    response = client.post(
        "/api/v1/comments/?postid=4",
        headers={"Authorization": f"Basic {credentials}"},
        data=json.dumps({"text": "new comment"}),
    )
    assert response.status_code == 201
    response_json = response.get_json()
    assert response_json == {
        "commentid": 8,
        "lognameOwnsThis": True,
        "owner": "awdeorio",
        "ownerShowUrl": "/users/awdeorio/",
        "text": "new comment",
        "url": "/api/v1/comments/8/"
    }


    # create new comment with empty text
    response = client.post(
        "/api/v1/comments/?postid=4",
        headers={"Authorization": f"Basic {credentials}"},
        data=json.dumps({"text": ""}),
    )
    assert response.status_code == 400
    response_json = response.get_json()
    assert response_json == {
        "message": "Bad Request",
        "status_code": 400
    }


    # try to delete a commentid that does not exist
    response = client.delete(
        "/api/v1/comments/10/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 404
    response_json = response.get_json()
    assert response_json == {
        "message": "Not Found",
        "status_code": 404
    }


    # try to delete a comment that logname does not own
    response = client.delete(
        "/api/v1/comments/7/",
        headers={"Authorization": f"Basic {credentials}"}
    )
    assert response.status_code == 403
    response_json = response.get_json()
    assert response_json == {
        "message": "Forbidden",
        "status_code": 403
    }
